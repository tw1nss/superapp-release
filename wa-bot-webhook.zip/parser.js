/**
 * parser.js - Parser pesan WhatsApp Complain untuk GoWA Gateway
 * Mendeteksi trigger keyword (Hub MTG Menteng / Hub Astro Menteng)
 * dan mengekstrak No Invoice, Pengirim/Customer, dan Deskripsi Complain.
 */

// Default trigger keywords khusus Hub MTG / Menteng (case-insensitive)
// Jika pesan tidak mengandung Hub MTG atau Menteng, pesan di-skip karena beda gudang.
const DEFAULT_TRIGGERS = [
  'hub mtg menteng',
  'hub astro menteng',
  'hub : mtg',
  'hub: mtg',
  'hub:mtg',
  'hub mtg',
  'hub menteng',
  'astro menteng',
  'mtg menteng',
  'menteng'
];

// Regex pendeteksi kata kunci cancel / pembatalan pesanan
const CANCEL_PATTERN = /(?:^|\b|\*)(cancel|canceled|cancelled|batal|dibatalkan|cancellation|cancelan|order\s*cancel|cancel\s*order|batal\s*order)(?:\b|\*|:|$)/i;

// Regex pendeteksi keluhan / complain produk
const COMPLAIN_PATTERN = /(complain|komplain|retur|rusak|bocor|pecah|cacat|kurang|busuk|basi|expired|kadaluarsa|salah|hilang|sobek|tidak sesuai|masalah|kendala|klaim)/i;

function sanitizeWaText(str) {
  if (!str || typeof str !== 'string') return '';
  return str.replace(/[*_~`]/g, ' ').replace(/\s+/g, ' ').trim();
}

/**
 * Memeriksa apakah teks mengandung kata kunci cancel / pembatalan order
 */
function checkCancelKeyword(text) {
  if (!text || typeof text !== 'string') return false;
  return CANCEL_PATTERN.test(text) || CANCEL_PATTERN.test(sanitizeWaText(text));
}

/**
 * Memeriksa apakah teks mengandung kata kunci komplain produk
 */
function checkComplainKeyword(text) {
  if (!text || typeof text !== 'string') return false;
  return COMPLAIN_PATTERN.test(text) || COMPLAIN_PATTERN.test(sanitizeWaText(text));
}

/**
 * Memeriksa apakah pesan mengandung salah satu trigger keyword Hub MTG / Menteng
 * @param {string} text - Pesan WhatsApp mentah
 * @param {string[]} [customTriggers] - Opsional custom trigger list
 * @returns {{ isTriggered: boolean, matchedTrigger: string|null }}
 */
function checkTrigger(text, customTriggers = []) {
  if (!text || typeof text !== 'string') {
    return { isTriggered: false, matchedTrigger: null };
  }

  const cleanOriginal = text.toLowerCase();
  const unformatted = sanitizeWaText(text).toLowerCase();
  const triggers = (customTriggers.length > 0 ? customTriggers : DEFAULT_TRIGGERS);

  for (const trigger of triggers) {
    const t = trigger.toLowerCase().trim();
    if (cleanOriginal.includes(t) || unformatted.includes(t)) {
      return { isTriggered: true, matchedTrigger: trigger };
    }
  }

  // Cek jika ada kombinasi "hub" dan "mtg" atau "menteng" (mendukung "*Hub : MTG*", "Hub : MTG", "Hub: MTG", "Hub MTG", dll)
  if (unformatted.includes('menteng') || /hub\s*[:=\-]?\s*mtg/i.test(unformatted) || (unformatted.includes('hub') && unformatted.includes('mtg'))) {
    return { isTriggered: true, matchedTrigger: 'Hub MTG Menteng' };
  }

  return { isTriggered: false, matchedTrigger: null };
}

/**
 * Ekstrak No Invoice dari teks
 * Mendukung format:
 * - INV-2026-0912
 * - INV/2026/09/11/001
 * - No Invoice: INV12345
 * - Inv: #99212
 * - INV_99120
 * - Format dengan bold: *No Invoice:* INV/2026/09/101
 * - Format cancel: Cancel INV-xxx, Batal order INV/...
 */
function extractInvoice(text) {
  if (!text) return 'INV-UNSPECIFIED';

  const clean = sanitizeWaText(text);
  const targetTexts = [text, clean];

  // 1. Pola format umum invoice terlebih dahulu: INV-..., INV/..., ASTRO-..., MTG-...
  const generalPatterns = [
    /\b(INV[_\-\/][A-Za-z0-9_\-\/]{3,30})\b/i,
    /\b(ASTRO[_\-\/][A-Za-z0-9_\-\/]{3,30})\b/i,
    /\b(MTG[_\-\/][A-Za-z0-9_\-\/]{3,30})\b/i,
    /\b(INV[0-9]{4,20})\b/i
  ];

  for (const t of targetTexts) {
    for (const pattern of generalPatterns) {
      const match = t.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
  }

  // 2. Pola label eksplisit: "Inv:", "No Invoice:", "Invoice:", dll.
  const explicitPatterns = [
    /(?:no\.?\s*(?:invoice|inv|pesanan|order)|(?:invoice|inv|order)\s*(?:no|number)?)\s*[:=\s]\s*#?\s*([A-Za-z0-9_\-\/]{4,35})/i,
    /\b(?:invoice|inv)\b\s*[:=\s]\s*#?\s*([A-Za-z0-9_\-\/]{4,35})/i,
    // Pola khusus pesan cancel: "cancel inv-1234", "batal order #12345"
    /(?:cancel|batal|dibatalkan)\s+(?:order\s+|pesanan\s+)?#?\s*([A-Za-z0-9_\-\/]{4,35})/i
  ];

  for (const t of targetTexts) {
    for (const pattern of explicitPatterns) {
      const match = t.match(pattern);
      if (match && match[1]) {
        const inv = match[1].trim();
        // Pastikan bukan kata umum seperti "rusak" atau "barang"
        if (!/^(rusak|barang|pecah|kurang|pending|retur|bocor|order|pesanan|segera|tolong)$/i.test(inv)) {
          return inv;
        }
      }
    }
  }

  // 3. Pola nomor order Astro numerik murni (7-10 digit, contoh: 57200436, #57200436)
  const numericPatterns = [
    /(?:order|pesanan|inv|invoice|no|#)\s*[:=\s]?\s*#?([0-9]{7,10})\b/i,
    /(?:^|\s)#([0-9]{7,10})\b/,
    /\b([0-9]{8})\b/
  ];

  for (const t of targetTexts) {
    for (const pattern of numericPatterns) {
      const match = t.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
  }

  return 'INV-PENDING';
}

/**
 * Ekstrak nama Hub dari teks atau gunakan trigger yang cocok
 */
function extractHub(text, matchedTrigger) {
  if (!text) return 'Hub MTG Menteng';

  const clean = sanitizeWaText(text).toLowerCase();

  if (clean.includes('astro menteng')) return 'Hub Astro Menteng';
  if (clean.includes('mtg menteng')) return 'Hub MTG Menteng';
  if (/hub\s*[:=\-]?\s*astro/i.test(clean)) return 'Hub Astro Menteng';
  if (/hub\s*[:=\-]?\s*mtg/i.test(clean)) return 'Hub MTG Menteng';
  if (clean.includes('menteng')) return 'Hub MTG Menteng';
  if (/\bmtg\b/i.test(clean)) return 'Hub MTG Menteng';

  if (matchedTrigger) {
    if (/astro/i.test(matchedTrigger)) return 'Hub Astro Menteng';
    if (/mtg/i.test(matchedTrigger)) return 'Hub MTG Menteng';
  }

  return 'Hub MTG Menteng';
}

/**
 * Ekstrak Pengirim / Customer dari teks
 */
function extractSender(text, fallbackSender = 'Customer') {
  if (!text) return fallbackSender;

  const clean = sanitizeWaText(text);
  const targetTexts = [text, clean];

  const senderPatterns = [
    /(?:pengirim|customer|cust|nama|user|client|pembeli)\s*[:=\-]?\s*([^\n\r,]+)/i,
    /(?:dari|by)\s*[:=\-]?\s*([^\n\r,]+)/i
  ];

  for (const t of targetTexts) {
    for (const pattern of senderPatterns) {
      const match = t.match(pattern);
      if (match && match[1]) {
        const val = match[1].replace(/[*_~`]/g, '').trim();
        if (val.length > 1 && !/^(inv|hub|detail|complain|masalah|cancel|batal)/i.test(val)) {
          return val;
        }
      }
    }
  }

  return fallbackSender;
}

/**
 * Ekstrak Deskripsi Masalah / Alasan Cancel dari teks
 */
function extractDescription(text) {
  if (!text) return 'Tidak ada deskripsi detail.';

  // 1. Coba cari baris dengan label: Detail:, Keluhan:, Masalah:, Kendala:, Deskripsi:, Alasan:, Keterangan:
  const descPatterns = [
    /(?:detail|keluhan|masalah|kendala|deskripsi|alasan|keterangan|note|catatan)\s*[:=\-]?\s*([\s\S]+?)(?:\n\s*(?:pengirim|cust|customer|inv|invoice|hub)|$)/i
  ];

  for (const pattern of descPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const desc = match[1].replace(/^[*_~`]+|[*_~`]+$/g, '').trim();
      if (desc.length > 3) {
        return desc;
      }
    }
  }

  // 2. Jika tidak ada label spesifik, ambil seluruh teks baris yang bukan header/invoice/pengirim
  const lines = text.split(/\r?\n/)
    .map(l => l.trim())
    .filter(l => {
      if (!l) return false;
      const cleanLine = sanitizeWaText(l);
      if (/^(hub\s+|astro\s+|mtg\s+|\*complain|\*hub)/i.test(cleanLine)) return false;
      if (/^(inv|invoice|no\.?\s*inv)/i.test(cleanLine)) return false;
      if (/^(pengirim|customer|cust|nama)/i.test(cleanLine)) return false;
      return true;
    });

  if (lines.length > 0) {
    return lines.join(' ');
  }

  // Fallback: seluruh teks asli
  return text.trim();
}

/**
 * Parse pesan WhatsApp mentah menjadi structured complain / cancel object
 * @param {string} rawText - Teks pesan WhatsApp
 * @param {object} meta - Metadata dari webhook (sender name, phone, timestamp, msgId, groupJid, isCxQaGroup, groupName)
 * @param {string[]} [customTriggers] - Opsional custom trigger keywords
 * @returns {object|null} Complain / Cancel object jika trigger cocok, null jika tidak
 */
function parseComplainMessage(rawText, meta = {}, customTriggers = []) {
  if (!rawText || typeof rawText !== 'string') return null;

  // Deteksi apakah pesan berasal dari Private Message (1-on-1 langsung ke bot) atau Grup WA
  const isGroup = Boolean(meta.fromGroup && meta.fromGroup.endsWith('@g.us'));
  const isDirectChat = !isGroup;
  const isCxGroup = Boolean(meta.isCxQaGroup);

  // ─── 1. JIKA PESAN JAPRI / DIRECT CHAT KE BOT: ───
  // Aturan baru: Foto via japri atau chat biasa TIDAK BOLEH otomatis jadi task complain!
  // Task complain dan notifikasi cancel HANYA dipicu dari grup WhatsApp resmi (CX <> QA Fresh Discussion).
  if (isDirectChat) {
    return null;
  }

  const invoice = extractInvoice(rawText);
  const hasDetectedInvoice = invoice && invoice !== 'INV-PENDING' && invoice !== 'INV-UNSPECIFIED';
  const { isTriggered, matchedTrigger } = checkTrigger(rawText, customTriggers);

  const isCancel = checkCancelKeyword(rawText);
  const hasComplainWord = checkComplainKeyword(rawText);
  const hasImage = Boolean(meta.productImageUrl || meta.imageUrl || meta.image || meta.mediaUrl);

  // ─── 2. JIKA DARI GRUP CX <> QA FRESH DISCUSSION: ───
  if (isCxGroup) {
    // Di grup CX <> QA Fresh Discussion:
    // - Jika pesan Cancel (ada kata cancel/batal): harus mengandung invoice atau kata cancel yang valid
    // - Jika pesan Complain: ada kata complain/keluhan ATAU ada foto kendala produk ATAU menyebutkan Hub MTG
    const isRelevantCxMessage = isCancel || hasComplainWord || hasImage || isTriggered || hasDetectedInvoice;
    if (!isRelevantCxMessage) {
      return null;
    }
  } else {
    // ─── 3. JIKA DARI GRUP LAIN (BUKAN CX <> QA FRESH DISCUSSION): ───
    // Di grup lain yang multi-hub, pesan WAJIB dan MUTLAK menyebutkan Hub MTG Menteng / Hub Astro Menteng.
    // Jika tidak ada kata Hub MTG / Menteng, pesan HARUS DIABAIKAN.
    if (!isTriggered) {
      return null;
    }
  }

  const itemType = isCancel ? 'cancel' : 'complain';
  const now = new Date();
  const hub = extractHub(rawText, matchedTrigger);
  const defaultSender = isCxGroup ? 'Tim CX (Fresh Discussion)' : 'Customer';
  const sender = extractSender(rawText, meta.senderName || meta.pushName || defaultSender);
  const description = extractDescription(rawText);
  const productImageUrl = meta.productImageUrl || meta.imageUrl || meta.image || meta.photo || meta.mediaUrl || meta.media_url || null;

  // Generate unique ID
  const randomSuffix = Math.random().toString(36).substring(2, 7);
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const prefix = isCancel ? 'ccl' : 'cpl';
  const id = `${prefix}-${dateStr}-${randomSuffix}`;

  return {
    id,
    type: itemType, // 'cancel' | 'complain'
    hub,
    invoice,
    sender,
    description,
    productImageUrl,
    status: 'baru', // 'baru' | 'dikerjakan' | 'selesai'
    createdAt: now.toISOString(),
    claimedBy: null,
    claimedAt: null,
    resolvedAt: null,
    evidenceUrl: null,
    rawText,
    source: {
      platform: 'whatsapp',
      gateway: 'gowa',
      messageId: meta.messageId || null,
      fromGroup: meta.fromGroup || null,
      groupName: meta.groupName || null,
      isCxQaGroup: isCxGroup,
      senderPhone: meta.senderPhone || null,
      senderName: meta.senderName || meta.pushName || null,
      timestamp: meta.timestamp || Math.floor(now.getTime() / 1000)
    }
  };
}

module.exports = {
  checkTrigger,
  checkCancelKeyword,
  checkComplainKeyword,
  extractInvoice,
  extractHub,
  extractSender,
  extractDescription,
  parseComplainMessage,
  DEFAULT_TRIGGERS
};

