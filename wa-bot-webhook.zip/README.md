# 🤖 GoWA Bot Webhook & Complain Service — SuperApp MTG

Layanan backend cerdas untuk mendengarkan pesan dari WhatsApp Gateway **GoWA** (di VPS lokal rumah), mendeteksi trigger keluhan **Hub MTG Menteng** / **Hub Astro Menteng**, mengekstrak detail (Invoice, Nama, Keluhan), menyimpannya ke **Firestore / Local DB**, serta mengirimkan **FCM Push Notification** seketika ke seluruh smartphone staf yang menginstall **SuperApp MTG**.

---

## 🏗️ Alur Kerja Sistem (Flow Architecture)

```
[ WhatsApp Group ]
        │
        ▼ (Pesan masuk ada kata: "Hub MTG Menteng" / "Hub Astro Menteng")
[ GoWA Gateway di VPS ]
        │
        ▼ (Webhook HTTP POST /webhook)
[ wa-bot-webhook/server.js ]
        │
        ├── 1. Parser membaca: Hub, No Invoice, Pengirim, Detail Keluhan
        ├── 2. Simpan data complain ke Firestore (collection 'complaints')
        └── 3. Kirim FCM Push Notification ke Topic 'mtg_complaints'
                 │
                 ▼
[ Smartphone Android (SuperApp MTG) ]
        ├── Notifikasi muncul: "🚨 Complain Baru: Hub MTG Menteng - INV-xxx"
        └── User tap notifikasi -> Aplikasi langsung terbuka di Menu Complain
                 │
                 ▼
[ Menu Complain SuperApp ]
        ├── User klik "Cek Detail"
        ├── User klik "Kerjakan Complain Ini" (Status: Dikerjakan)
        ├── User balas di grup WA lalu screenshot buktinya
        ├── Upload screenshot di aplikasi & klik "Tandai Selesai"
        └── Status otomatis berubah menjadi "Selesai" ✅
```

---

## 🚀 Panduan Instalasi di VPS Lokal

### 1. Masuk ke Folder Webhook
Salin folder `wa-bot-webhook` ke VPS Anda (tempat GoWA berjalan atau VPS terpisah):
```bash
cd wa-bot-webhook
npm install
```

### 2. Konfigurasi File `.env`
Salin template konfigurasi:
```bash
cp .env.example .env
```
Buka file `.env` dan sesuaikan jika diperlukan:
```ini
PORT=3100
FCM_TOPIC=mtg_complaints
FIREBASE_SERVICE_ACCOUNT=./firebase-service-account.json
```

### 3. Tambahkan Kredensial Firebase (Opsional tapi Direkomendasikan untuk FCM)
Untuk mengaktifkan pengiriman Push Notification FCM & Cloud Firestore:
1. Buka [Firebase Console](https://console.firebase.google.com/).
2. Masuk ke **Project Settings** (ikon gerigi) -> Tab **Service Accounts**.
3. Klik tombol **Generate New Private Key**.
4. Simpan file JSON tersebut dengan nama `firebase-service-account.json` di dalam folder `wa-bot-webhook/`.

> *Catatan: Jika belum ada Firebase, server tetap dapat berjalan dengan local database (`complaints_db.json`) dan menyediakan REST API.*

### 4. Jalankan Service di VPS
Untuk pengembangan / uji coba:
```bash
npm start
```
Untuk produksi (agar berjalan terus di background VPS menggunakan PM2):
```bash
npm install -g pm2
pm2 start server.js --name "superapp-complain-bot"
pm2 save
pm2 startup
```

---

## 🔗 Menghubungkan GoWA Gateway ke Webhook

Di setting GoWA Anda (biasanya di file `.env` GoWA atau dashboard web GoWA):
Atur Webhook URL ke endpoint webhook server ini:
```
WEBHOOK_URL=http://localhost:3100/webhook
```
*(Atau gunakan IP lokal VPS jika GoWA dan bot berada di container/mesin berbeda, misalnya `http://192.168.1.100:3100/webhook`)*.

---

## 🧪 Cara Menguji Webhook

### 1. Uji Coba Parser Unit Tests
Pastikan logika ekstraksi berjalan sempurna:
```bash
node test_parser.js
```

### 2. Simulasi Webhook Pesan WA Masuk
Jalankan skrip simulasi pesan masuk seolah-olah dikirim oleh GoWA:
```bash
node simulate_webhook.js
```

---

## 📋 Format Pesan WhatsApp yang Didukung

Bot mendukung berbagai variasi format pesan, asalkan mengandung trigger `Hub MTG Menteng` atau `Hub Astro Menteng`:

### Contoh 1: Format Berbaris Standar
```text
Hub MTG Menteng
Invoice: INV-2026-0912
Pengirim: PT Sinar Jaya
Detail: Kardus basah dan sobek di sudut, isi kurang 1 botol kecap.
```

### Contoh 2: Format Astro Menteng
```text
Hub Astro Menteng
No Inv: ASTRO-99120
Customer: Ibu Maria
Keluhan: Buah apel lecet dan tidak layak jual.
```

### Contoh 3: Format Singkat / Chat Casual
```text
Tolong dicek Hub MTG Menteng inv INV-8821 customer Budi barang salah varian rasa ya.
```

---

## 📡 Daftar REST API Endpoints

| Method | Endpoint | Deskripsi |
| :--- | :--- | :--- |
| `POST` | `/webhook` | Menerima payload pesan masuk dari GoWA gateway |
| `GET` | `/api/complaints` | Mengambil seluruh daftar complain (filter: `?status=baru`) |
| `POST` | `/api/complaints/:id/claim` | Mengklaim complain (`dikerjakan`) |
| `POST` | `/api/complaints/:id/resolve` | Menyelesaikan complain dengan menyertakan screenshot bukti |
| `POST` | `/api/simulate-complain` | Membuat data complain dummy untuk pengujian aplikasi |
| `GET` | `/health` | Status server, total data, dan koneksi Firebase |
