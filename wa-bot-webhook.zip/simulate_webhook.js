/**
 * simulate_webhook.js - Skrip simulasi pengiriman webhook dari GoWA Gateway
 * Mendukung simulasi:
 * - node simulate_webhook.js cancel   (Simulasi pesan cancel order di grup CX)
 * - node simulate_webhook.js complain (Simulasi pesan complain di grup CX)
 * - node simulate_webhook.js japri    (Simulasi foto via japri ke bot - harus diabaikan)
 */

const http = require('http');

const mode = (process.argv[2] || 'cancel').toLowerCase();

let samplePayload;

if (mode === 'japri') {
  samplePayload = {
    event: 'message',
    data: {
      id: '3EB0_JAPRI_' + Date.now(),
      from: '628123456789@s.whatsapp.net',
      sender: '628123456789@s.whatsapp.net',
      push_name: 'Customer Japri',
      message: '',
      image: 'data:image/jpeg;base64,samplephoto',
      timestamp: Math.floor(Date.now() / 1000)
    }
  };
} else if (mode === 'complain') {
  samplePayload = {
    event: 'message',
    data: {
      id: '3EB0_CPL_' + Date.now(),
      from: '120363048999999999@g.us', // ID Grup WA
      chat_name: 'CX <> QA Fresh Discussion',
      sender: '6281298765432@s.whatsapp.net',
      push_name: 'Budi (Ops Menteng)',
      message: `Hub MTG Menteng\nInvoice: INV-2026-0920-882\nPengirim: Ibu Amanda\nDetail: Pesanan ada buah mangga busuk 2 pcs dan susu pecah. Tolong segera direply dan diganti.`,
      timestamp: Math.floor(Date.now() / 1000)
    }
  };
} else {
  // Default: Cancel
  samplePayload = {
    event: 'message',
    data: {
      id: '3EB0_CCL_' + Date.now(),
      from: '120363048999999999@g.us', // ID Grup WA
      chat_name: 'CX <> QA Fresh Discussion',
      sender: '6281211112222@s.whatsapp.net',
      push_name: 'Sarah CX Team',
      message: `Cancel order INV/2026/09/20/0991\nAlasan: Customer batalkan pesanan karena salah varian barang\nTolong distop proses packing ya tim Menteng.`,
      timestamp: Math.floor(Date.now() / 1000)
    }
  };
}

const payloadData = JSON.stringify(samplePayload);

const options = {
  hostname: 'localhost',
  port: process.env.PORT || 3100,
  path: '/webhook',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payloadData)
  }
};

console.log(`📤 Mengirim simulasi webhook pesan WA (${mode.toUpperCase()}) ke http://localhost:3100/webhook ...`);
console.log('Isi Pesan:\n', samplePayload.data.message || '[Hanya Foto]');
console.log('\n---');

const req = http.request(options, (res) => {
  let responseData = '';
  res.on('data', (chunk) => { responseData += chunk; });
  res.on('end', () => {
    console.log(`HTTP Status: ${res.statusCode}`);
    try {
      const parsed = JSON.parse(responseData);
      console.log('Respon Server:\n', JSON.stringify(parsed, null, 2));
    } catch (e) {
      console.log('Respon Mentah:\n', responseData);
    }
  });
});

req.on('error', (e) => {
  console.error(`❌ Gagal menghubungi server: ${e.message}`);
  console.log('Pastikan server sudah berjalan dengan: npm start (di folder wa-bot-webhook)');
});

req.write(payloadData);
req.end();
