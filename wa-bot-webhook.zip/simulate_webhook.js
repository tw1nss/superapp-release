/**
 * simulate_webhook.js - Skrip simulasi pengiriman webhook dari GoWA Gateway
 * Berguna untuk menguji apakah webhook receiver dan parsing bekerja dengan benar.
 */

const http = require('http');

const samplePayload = {
  event: 'message',
  data: {
    id: '3EB0_MOCK_' + Date.now(),
    from: '120363048999999999@g.us', // ID Grup WA
    sender: '6281298765432@s.whatsapp.net',
    push_name: 'Budi (Ops Menteng)',
    message: `Hub MTG Menteng
Invoice: INV-2026-0912-882
Pengirim: Ibu Amanda
Detail: Pesanan ada buah mangga busuk 2 pcs dan susu pecah. Tolong segera direply dan diganti.`,
    timestamp: Math.floor(Date.now() / 1000)
  }
};

const payloadData = JSON.stringify(samplePayload);

const options = {
  hostname: 'localhost',
  port: process.env.PORT || 3100,
  path: '/webhook',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payloadData)
  }
};

console.log('📤 Mengirim simulasi webhook pesan WA ke http://localhost:3100/webhook ...');
console.log('Isi Pesan:\n', samplePayload.data.message);
console.log('\n---');

const req = http.request(options, (res) => {
  let responseData = '';
  res.on('data', (chunk) => { responseData += chunk; });
  res.on('end', () => {
    console.log(`HTTP Status: ${res.statusCode}`);
    try {
      const parsed = JSON.parse(responseData);
      console.log('Respon Server:\n', JSON.stringify(parsed, null, 2));
    } catch (e) {
      console.log('Respon Mentah:\n', responseData);
    }
  });
});

req.on('error', (e) => {
  console.error(`❌ Gagal menghubungi server: ${e.message}`);
  console.log('Pastikan server sudah berjalan dengan: npm start (di folder wa-bot-webhook)');
});

req.write(payloadData);
req.end();
