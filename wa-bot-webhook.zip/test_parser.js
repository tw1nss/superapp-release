/**
 * test_parser.js - Test suite untuk memvalidasi akurasi ekstraksi parser WhatsApp
 */

const { parseComplainMessage, checkTrigger, extractInvoice } = require('./parser');

console.log('🧪 Menjalankan pengujian parser WhatsApp Complain...');

const testCases = [
  {
    name: 'Format Standar Berbaris (Hub MTG Menteng)',
    input: `Hub MTG Menteng
Invoice: INV-2026-0912
Pengirim: PT ABC Logistik
Detail: Kardus penyok, isi bocor 3 pcs botol sirup`,
    expected: {
      hub: 'Hub MTG Menteng',
      invoice: 'INV-2026-0912',
      sender: 'PT ABC Logistik',
      description: 'Kardus penyok, isi bocor 3 pcs botol sirup'
    }
  },
  {
    name: 'Format Astro Menteng dengan Bintang (Markdown WA)',
    input: `*Hub Astro Menteng*
No Invoice: INV/2026/09/11/088
Customer: Ibu Ratna Dewi
Keluhan: Telur pecah 6 butir dan sayur layu`,
    expected: {
      hub: 'Hub Astro Menteng',
      invoice: 'INV/2026/09/11/088',
      sender: 'Ibu Ratna Dewi',
      description: 'Telur pecah 6 butir dan sayur layu'
    }
  },
  {
    name: 'Format Singkat Casual',
    input: `Tolong dicek Hub MTG Menteng inv INV-8821 customer Budi barang kurang 2 susu ultra`,
    expected: {
      hub: 'Hub MTG Menteng',
      invoice: 'INV-8821'
    }
  },
  {
    name: 'Pesan Tanpa Trigger dan Tanpa Invoice di Grup (Harus Diabaikan/Null)',
    input: `Halo selamat siang tim, besok ada jadwal stock opname di warehouse barat jam 9 pagi ya.`,
    expected: null,
    isGroup: true
  },
  {
    name: 'Format Forwardan dengan Timestamp',
    input: `[11/09/2026 10.30] CS Astro: 
Pagi tim Hub Astro Menteng,
Inv: ASTRO-MTG-9021
Pengirim: Toko Berkah Jaya
Kendala: Salah kirim varian rasa minyak goreng`,
    expected: {
      hub: 'Hub Astro Menteng',
      invoice: 'ASTRO-MTG-9021',
      sender: 'Toko Berkah Jaya',
      description: 'Salah kirim varian rasa minyak goreng'
    },
    isGroup: true
  },
  {
    name: 'Pesan Hanya Invoice Tanpa Kata Hub MTG / Menteng (Wajib Di-skip Karena Beda Gudang)',
    input: `Min tolong ada komplain pesanan INV-2026-9912 barang rusak botol kecap pecah di gudang lain`,
    expected: null,
    isGroup: true
  },
  {
    name: 'Pesan dengan Kata Kunci Menteng (Harus Diproses Sebagai Hub MTG Menteng)',
    input: `Ada komplain menteng untuk pesanan INV-7712 kemasan sobek`,
    expected: {
      hub: 'Hub MTG Menteng',
      invoice: 'INV-7712'
    },
    isGroup: true
  }
];

let passed = 0;
let failed = 0;

testCases.forEach((tc, index) => {
  console.log(`\n──────────────────────────────────────────────────────────`);
  console.log(`Test ${index + 1}: ${tc.name}`);

  const meta = {
    senderName: 'QA Reporter',
    senderPhone: '6281234567890',
    messageId: 'MSG-00' + index,
    fromGroup: tc.isGroup === false ? '6281234567890@s.whatsapp.net' : '120363048999999999@g.us'
  };

  const result = parseComplainMessage(tc.input, meta);

  if (tc.expected === null) {
    if (result === null) {
      console.log(`  ✅ Lolos: Pesan tanpa trigger berhasil diabaikan (null)`);
      passed++;
    } else {
      console.log(`  ❌ Gagal: Harusnya null, tapi menghasilkan:`, result);
      failed++;
    }
    return;
  }

  if (!result) {
    console.log(`  ❌ Gagal: Parser menghasilkan null padahal ada trigger!`);
    failed++;
    return;
  }

  let ok = true;
  if (tc.expected.hub && result.hub !== tc.expected.hub) {
    console.log(`  ❌ Hub Mismatch: Dapat "${result.hub}", Harusnya "${tc.expected.hub}"`);
    ok = false;
  }
  if (tc.expected.invoice && result.invoice !== tc.expected.invoice) {
    console.log(`  ❌ Invoice Mismatch: Dapat "${result.invoice}", Harusnya "${tc.expected.invoice}"`);
    ok = false;
  }
  if (tc.expected.sender && result.sender !== tc.expected.sender) {
    console.log(`  ❌ Sender Mismatch: Dapat "${result.sender}", Harusnya "${tc.expected.sender}"`);
    ok = false;
  }
  if (tc.expected.description && !result.description.includes(tc.expected.description)) {
    console.log(`  ❌ Desc Mismatch: Dapat "${result.description}", Harusnya mengandung "${tc.expected.description}"`);
    ok = false;
  }

  if (ok) {
    console.log(`  ✅ Lolos! Hasil ekstraksi:`);
    console.log(`     - Hub    : ${result.hub}`);
    console.log(`     - Invoice: ${result.invoice}`);
    console.log(`     - Pengirim: ${result.sender}`);
    console.log(`     - Detail : ${result.description}`);
    passed++;
  } else {
    failed++;
  }
});

console.log(`\n══════════════════════════════════════════════════════════`);
console.log(`📊 Hasil Pengujian Parser: ${passed} Lolos, ${failed} Gagal`);
console.log(`══════════════════════════════════════════════════════════`);

if (failed > 0) {
  process.exit(1);
} else {
  console.log('🎉 Semua tes parser berhasil 100%!\n');
}
