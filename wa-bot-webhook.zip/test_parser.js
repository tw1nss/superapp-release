/**
 * test_parser.js - Test suite untuk memvalidasi akurasi ekstraksi parser WhatsApp
 * Menguji skenario Complain, Cancel Order, CX <> QA Fresh Discussion, dan Penolakan Japri
 */

const { parseComplainMessage, checkTrigger, extractInvoice, checkCancelKeyword } = require('./parser');

console.log('🧪 Menjalankan pengujian parser WhatsApp Complain & Cancel Order...');

const testCases = [
  {
    name: 'Format Standar Berbaris (Hub MTG Menteng)',
    input: `Hub MTG Menteng
Invoice: INV-2026-0912
Pengirim: PT ABC Logistik
Detail: Kardus penyok, isi bocor 3 pcs botol sirup`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: false },
    expected: {
      type: 'complain',
      hub: 'Hub MTG Menteng',
      invoice: 'INV-2026-0912',
      sender: 'PT ABC Logistik',
      description: 'Kardus penyok, isi bocor 3 pcs botol sirup'
    }
  },
  {
    name: 'Format Astro Menteng dengan Bintang (Markdown WA)',
    input: `*Hub Astro Menteng*
No Invoice: INV/2026/09/11/088
Customer: Ibu Ratna Dewi
Keluhan: Telur pecah 6 butir dan sayur layu`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: false },
    expected: {
      type: 'complain',
      hub: 'Hub Astro Menteng',
      invoice: 'INV/2026/09/11/088',
      sender: 'Ibu Ratna Dewi',
      description: 'Telur pecah 6 butir dan sayur layu'
    }
  },
  {
    name: 'Notifikasi Cancel Order di Grup CX <> QA Fresh Discussion (Bug #1 Fix)',
    input: `Cancel order INV/2026/09/20/0812
Alasan: Customer batalkan pesanan karena salah alamat
Tolong distop packing ya tim`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: true, groupName: 'CX <> QA Fresh Discussion' },
    expected: {
      type: 'cancel',
      invoice: 'INV/2026/09/20/0812',
      description: 'Customer batalkan pesanan karena salah alamat'
    }
  },
  {
    name: 'Notifikasi Cancel Format Singkat di Grup CX (Bug #1 Fix)',
    input: `Cancel INV-99012 customer minta refund`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: true, groupName: 'CX <> QA Fresh Discussion' },
    expected: {
      type: 'cancel',
      invoice: 'INV-99012'
    }
  },
  {
    name: 'Pesan Foto via Japri ke Bot (Bug #2 Fix - Wajib Diabaikan/Null)',
    input: ``,
    meta: { fromGroup: null, senderPhone: '628123456789@s.whatsapp.net', productImageUrl: 'data:image/jpeg;base64,sample' },
    expected: null
  },
  {
    name: 'Pesan Teks Foto via Japri ke Bot Tanpa Grup (Bug #2 Fix - Wajib Diabaikan/Null)',
    input: `Halo bot ini foto barang`,
    meta: { fromGroup: null, senderPhone: '628123456789@s.whatsapp.net', productImageUrl: 'data:image/jpeg;base64,sample' },
    expected: null
  },
  {
    name: 'Pesan Complain dengan Foto di Grup CX <> QA Fresh Discussion',
    input: `Ada kendala barang rusak INV-2026-4412 susu bocor`,
    meta: {
      fromGroup: '120363048999999999@g.us',
      isCxQaGroup: true,
      groupName: 'CX <> QA Fresh Discussion',
      productImageUrl: 'data:image/jpeg;base64,sample'
    },
    expected: {
      type: 'complain',
      invoice: 'INV-2026-4412'
    }
  },
  {
    name: 'Pesan Obrolan Biasa di Grup CX Tanpa Complain & Tanpa Cancel (Harus Diabaikan/Null)',
    input: `Selamat pagi semuanya, jangan lupa meeting jam 10 ya`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: true },
    expected: null
  },
  {
    name: 'Pesan di Grup Lain Tanpa Kata Hub MTG Menteng (Harus Diabaikan/Null)',
    input: `Min tolong ada komplain pesanan INV-2026-9912 barang rusak botol kecap pecah di gudang lain`,
    meta: { fromGroup: '120363048999999999@g.us', isCxQaGroup: false },
    expected: null
  }
];

let passed = 0;
let failed = 0;

testCases.forEach((tc, index) => {
  console.log(`\n──────────────────────────────────────────────────────────`);
  console.log(`Test ${index + 1}: ${tc.name}`);

  const meta = Object.assign({
    senderName: 'QA Reporter',
    senderPhone: '6281234567890',
    messageId: 'MSG-00' + index,
    fromGroup: '120363048999999999@g.us'
  }, tc.meta || {});

  const result = parseComplainMessage(tc.input, meta);

  if (tc.expected === null) {
    if (result === null) {
      console.log(`  ✅ Lolos: Pesan berhasil diabaikan sesuai aturan (null)`);
      passed++;
    } else {
      console.log(`  ❌ Gagal: Harusnya null (diabaikan), tapi menghasilkan:`, result);
      failed++;
    }
    return;
  }

  if (!result) {
    console.log(`  ❌ Gagal: Parser menghasilkan null padahal ada trigger!`);
    failed++;
    return;
  }

  let ok = true;
  if (tc.expected.type && result.type !== tc.expected.type) {
    console.log(`  ❌ Type Mismatch: Dapat "${result.type}", Harusnya "${tc.expected.type}"`);
    ok = false;
  }
  if (tc.expected.hub && result.hub !== tc.expected.hub) {
    console.log(`  ❌ Hub Mismatch: Dapat "${result.hub}", Harusnya "${tc.expected.hub}"`);
    ok = false;
  }
  if (tc.expected.invoice && result.invoice !== tc.expected.invoice) {
    console.log(`  ❌ Invoice Mismatch: Dapat "${result.invoice}", Harusnya "${tc.expected.invoice}"`);
    ok = false;
  }
  if (tc.expected.sender && result.sender !== tc.expected.sender) {
    console.log(`  ❌ Sender Mismatch: Dapat "${result.sender}", Harusnya "${tc.expected.sender}"`);
    ok = false;
  }
  if (tc.expected.description && !result.description.includes(tc.expected.description)) {
    console.log(`  ❌ Desc Mismatch: Dapat "${result.description}", Harusnya mengandung "${tc.expected.description}"`);
    ok = false;
  }

  if (ok) {
    console.log(`  ✅ Lolos! Hasil ekstraksi:`);
    console.log(`     - Tipe   : ${result.type.toUpperCase()}`);
    console.log(`     - Hub    : ${result.hub}`);
    console.log(`     - Invoice: ${result.invoice}`);
    console.log(`     - Detail : ${result.description}`);
    passed++;
  } else {
    failed++;
  }
});

console.log(`\n══════════════════════════════════════════════════════════`);
console.log(`📊 Hasil Pengujian Parser: ${passed} Lolos, ${failed} Gagal`);
console.log(`══════════════════════════════════════════════════════════`);

if (failed > 0) {
  process.exit(1);
} else {
  console.log('🎉 Semua tes parser berhasil 100%!\n');
}
