/**
 * test_fcm.js - Alat diagnosa & pengujian Firebase Cloud Messaging (FCM)
 * Jalankan: node test_fcm.js
 */

const path = require('path');
const fs = require('fs');
const { checkFcmHealth, sendPushNotification, FCM_TOPIC } = require('./firebase-service');

async function run() {
  console.log('══════════════════════════════════════════════════════════');
  console.log('🔍 Diagnosa Koneksi Firebase Cloud Messaging (FCM)');
  console.log('══════════════════════════════════════════════════════════\n');

  const saPath = path.join(__dirname, 'firebase-service-account.json');
  if (!fs.existsSync(saPath)) {
    console.error('❌ File firebase-service-account.json TIDAK DITEMUKAN di folder wa-bot-webhook/');
    console.error('👉 Solusi: Download service account key baru dari Firebase Console.');
    process.exit(1);
  }

  const sa = JSON.parse(fs.readFileSync(saPath, 'utf8'));
  console.log('📄 Kredensial Terdeteksi:');
  console.log(`   - Project ID    : ${sa.project_id}`);
  console.log(`   - Client Email  : ${sa.client_email}`);
  console.log(`   - Private Key ID: ${sa.private_key_id}`);
  console.log(`   - Target Topic  : ${FCM_TOPIC}\n`);

  console.log('🔄 Memeriksa autentikasi token ke Google OAuth2 endpoint...');
  const health = await checkFcmHealth();

  if (health.ready) {
    console.log('✅ STATUS FCM: 100% SEHAT & AKTIF!');
    console.log('   Semua push notification FCM akan terkirim ke smartphone Android staf.');

    // Opsi tes kirim pesan
    if (process.argv.includes('--send')) {
      console.log('\n📤 Mengirim notifikasi tes nyata...');
      const testComplain = {
        id: 'test-' + Date.now(),
        type: 'complain',
        hub: 'Hub MTG Menteng',
        invoice: 'INV-TEST-' + Math.floor(1000 + Math.random() * 9000),
        sender: 'Test Diagnostic Tool',
        description: 'Ini adalah pesan tes notifikasi FCM dari SuperApp MTG bot.',
        productImageUrl: null,
        status: 'baru',
        createdAt: new Date().toISOString()
      };
      const res = await sendPushNotification(testComplain);
      console.log('Hasil pengiriman:', res);
    } else {
      console.log('\n💡 Tips: Jalankan `node test_fcm.js --send` jika ingin mengirim notifikasi tes nyata ke HP staf.');
    }
  } else {
    console.error('❌ STATUS FCM: GAGAL / TIDAK DAPAT MENGIRIM NOTIFIKASI');
    console.error(`   Alasan: ${health.error || health.reason}\n`);

    if (health.error && (health.error.includes('invalid_grant') || health.error.includes('Invalid JWT'))) {
      console.log('──────────────────────────────────────────────────────────');
      console.log('🚨 PENYEBAB UTAMA:');
      console.log('   Private Key Service Account pada file firebase-service-account.json');
      console.log('   sudah kedaluwarsa atau telah di-revoke/dihapus di Firebase Console.');
      console.log('──────────────────────────────────────────────────────────');
      console.log('📋 PANDUAN CARA MEMPERBAIKI DALAM 1 MENIT:');
      console.log('1. Buka browser: https://console.firebase.google.com/project/complain-m/settings/serviceaccounts/adminsdk');
      console.log('2. Di bagian "Firebase Admin SDK", klik tombol biru: "Generate new private key" (Buat kunci privat baru).');
      console.log('3. File JSON baru akan terunduh ke komputer Anda.');
      console.log('4. Ganti nama file tersebut menjadi: firebase-service-account.json');
      console.log('5. Letakkan / timpa file tersebut ke dalam folder:');
      console.log(`   ${__dirname}`);
      console.log('6. Jalankan kembali: node test_fcm.js');
      console.log('──────────────────────────────────────────────────────────\n');
    }
  }
}

run().catch(console.error);
