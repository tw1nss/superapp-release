/**
 * firebase-service.js - Integrasi Firebase Firestore & FCM Push Notification
 * Mendukung mode Hybrid: Direct Cloud Firestore REST + Firebase Admin SDK + Local Storage Backup
 */

const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const { safeFetch } = require('./safe_fetch');

dotenv.config();

let admin = null;
let db = null;
let messaging = null;
let isFirebaseReady = false;

const LOCAL_STORAGE_FILE = path.join(__dirname, 'complaints_db.json');
const FCM_TOPIC = process.env.FCM_TOPIC || 'mtg_complaints';
const FIRESTORE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'complain-m';
const FIRESTORE_REST_BASE = `https://firestore.googleapis.com/v1/projects/${FIRESTORE_PROJECT_ID}/databases/(default)/documents/complaints`;

// Inisialisasi Firebase Admin SDK jika file credentials ada
function initFirebase() {
  const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT || path.join(__dirname, 'firebase-service-account.json');

  try {
    if (fs.existsSync(serviceAccountPath)) {
      admin = require('firebase-admin');
      const serviceAccount = require(serviceAccountPath);

      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
      });

      db = admin.firestore();
      messaging = admin.messaging();
      isFirebaseReady = true;
      console.log('🔥 [Firebase] Terhubung ke Firebase Project via Admin SDK:', serviceAccount.project_id);
    } else {
      console.log('ℹ️ [Firebase] File firebase-service-account.json belum ada. Sinkronisasi menggunakan Direct Firestore REST API.');
    }
  } catch (err) {
    console.warn('⚠️ [Firebase] Gagal inisialisasi Firebase Admin SDK:', err.message);
    console.log('ℹ️ Menggunakan Direct Firestore REST API + Local Storage.');
  }

  // Inisialisasi local database file jika belum ada
  if (!fs.existsSync(LOCAL_STORAGE_FILE)) {
    fs.writeFileSync(LOCAL_STORAGE_FILE, JSON.stringify([], null, 2), 'utf8');
  }
}

// ─── Local JSON Helper ───
function getLocalComplaints() {
  try {
    if (!fs.existsSync(LOCAL_STORAGE_FILE)) return [];
    const content = fs.readFileSync(LOCAL_STORAGE_FILE, 'utf8');
    return JSON.parse(content || '[]');
  } catch (err) {
    console.error('Gagal membaca local complaints:', err.message);
    return [];
  }
}

function saveLocalComplaints(list) {
  try {
    fs.writeFileSync(LOCAL_STORAGE_FILE, JSON.stringify(list, null, 2), 'utf8');
  } catch (err) {
    console.error('Gagal menulis local complaints:', err.message);
  }
}

// ─── Direct Firestore REST Helpers (Bekerja otomatis tanpa perlu private key di VPS) ───
function encodeFirestoreFields(obj) {
  const fields = {};
  for (const k in obj) {
    const val = obj[k];
    if (val === null || val === undefined) {
      fields[k] = { nullValue: null };
    } else if (typeof val === 'string') {
      fields[k] = { stringValue: val };
    } else if (typeof val === 'number') {
      if (Number.isInteger(val)) {
        fields[k] = { integerValue: String(val) };
      } else {
        fields[k] = { doubleValue: val };
      }
    } else if (typeof val === 'boolean') {
      fields[k] = { booleanValue: val };
    } else if (typeof val === 'object') {
      try {
        fields[k] = { stringValue: JSON.stringify(val) };
      } catch (_) {
        fields[k] = { nullValue: null };
      }
    }
  }
  return fields;
}

async function syncToFirestoreRest(docId, data, updateMaskKeys = null) {
  try {
    if (!docId) return;
    const fields = encodeFirestoreFields(data);
    let url = `${FIRESTORE_REST_BASE}/${docId}`;
    if (updateMaskKeys && Array.isArray(updateMaskKeys) && updateMaskKeys.length > 0) {
      const mask = updateMaskKeys.map(k => `updateMask.fieldPaths=${k}`).join('&');
      url += `?${mask}`;
    }
    const res = await safeFetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields }),
      timeout: 6000
    });
    if (res.ok) {
      console.log(`☁️ [Firestore REST Sync] Sukses sinkron ${docId} ke Cloud`);
    } else {
      const txt = await res.text();
      console.warn(`⚠️ [Firestore REST Sync] Status ${res.status}: ${txt.substring(0, 120)}`);
    }
  } catch (e) {
    console.warn(`⚠️ [Firestore REST Sync] Gagal sinkron ${docId}: ${e.message}`);
  }
}

async function deleteFromFirestoreRest(docId) {
  try {
    if (!docId) return;
    await safeFetch(`${FIRESTORE_REST_BASE}/${docId}`, {
      method: 'DELETE',
      timeout: 6000
    });
    console.log(`☁️ [Firestore REST Sync] Sukses hapus ${docId} di Cloud`);
  } catch (e) {
    console.warn(`⚠️ [Firestore REST Sync] Gagal hapus ${docId}: ${e.message}`);
  }
}

/**
 * Simpan complain baru ke Firestore (REST + Admin SDK) dan Local Storage
 */
async function saveComplain(complain) {
  // 1. Simpan ke Local Storage terlebih dahulu
  const list = getLocalComplaints();
  const existingIdx = list.findIndex(c => c.id === complain.id);
  if (existingIdx >= 0) {
    list[existingIdx] = complain;
  } else {
    list.unshift(complain);
  }
  saveLocalComplaints(list);

  // 2. Simpan via Admin SDK jika tersedia
  if (isFirebaseReady && db) {
    try {
      await db.collection('complaints').doc(complain.id).set(complain);
      console.log(`✅ [Firestore Admin] Complain ${complain.id} berhasil disimpan.`);
    } catch (err) {
      console.error(`❌ [Firestore Admin] Gagal:`, err.message);
    }
  }

  // 3. SELALU sinkronkan ke Direct Cloud Firestore REST API
  await syncToFirestoreRest(complain.id, complain);

  return complain;
}

/**
 * Ambil semua complain (Real-time Cloud Sync)
 */
async function getAllComplaints(statusFilter = null) {
  // 1. Coba dari Firestore Admin SDK jika siap
  if (isFirebaseReady && db) {
    try {
      let query = db.collection('complaints').orderBy('createdAt', 'desc');
      if (statusFilter && statusFilter !== 'semua') {
        query = query.where('status', '==', statusFilter);
      }
      const snapshot = await query.get();
      const docs = [];
      snapshot.forEach(doc => docs.push(doc.data()));
      return docs;
    } catch (err) {
      console.warn('Fallback ke REST karena error Admin SDK:', err.message);
    }
  }

  // 2. Ambil langsung dari Cloud Firestore REST API
  try {
    const fsRes = await safeFetch(`${FIRESTORE_REST_BASE}?pageSize=200`, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache'
      },
      timeout: 4000
    });
    if (fsRes.ok) {
      const fsData = await fsRes.json();
      if (fsData && Array.isArray(fsData.documents)) {
        let docs = fsData.documents.map(d => {
          const f = d.fields || {};
          const getStr = (obj, key, fallback) => {
            return (obj && obj[key] && obj[key].stringValue !== undefined) ? obj[key].stringValue : (fallback || '');
          };
          return {
            id: getStr(f, 'id', d.name.split('/').pop()),
            type: getStr(f, 'type', 'complain'),
            hub: getStr(f, 'hub', 'Hub MTG Menteng'),
            invoice: getStr(f, 'invoice', ''),
            sender: getStr(f, 'sender', ''),
            description: getStr(f, 'description', ''),
            productImageUrl: (f.productImageUrl && f.productImageUrl.stringValue) || null,
            status: getStr(f, 'status', 'baru'),
            createdAt: getStr(f, 'createdAt', d.createTime),
            claimedBy: (f.claimedBy && f.claimedBy.stringValue) || null,
            claimedAt: (f.claimedAt && f.claimedAt.stringValue) || null,
            resolvedAt: (f.resolvedAt && f.resolvedAt.stringValue) || null,
            evidenceUrl: (f.evidenceUrl && f.evidenceUrl.stringValue) || null,
            rawText: getStr(f, 'rawText', '')
          };
        });

        docs.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

        if (statusFilter && statusFilter !== 'semua') {
          docs = docs.filter(c => c.status === statusFilter);
        }
        return docs;
      }
    }
  } catch (err) {
    console.warn('Fallback ke local storage karena Firestore REST error:', err.message);
  }

  // 3. Fallback ke local storage
  let list = getLocalComplaints();
  if (statusFilter && statusFilter !== 'semua') {
    list = list.filter(c => c.status === statusFilter);
  }
  return list;
}

/**
 * Klaim complain (ubah status ke 'dikerjakan' dan catat Nama PIC)
 */
async function claimComplain(id, userName = 'Warehouse User') {
  const now = new Date().toISOString();
  let updatedItem = null;

  // 1. Update di local storage
  const list = getLocalComplaints();
  const item = list.find(c => c.id === id);
  if (item) {
    item.status = 'dikerjakan';
    item.claimedBy = userName;
    item.claimedAt = now;
    saveLocalComplaints(list);
    updatedItem = item;
  }

  // 2. Update via Admin SDK jika aktif
  if (isFirebaseReady && db) {
    try {
      await db.collection('complaints').doc(id).update({
        status: 'dikerjakan',
        claimedBy: userName,
        claimedAt: now
      });
    } catch (err) {
      console.error('Error updating claim in Firestore Admin:', err.message);
    }
  }

  // 3. SELALU sinkronkan ke Direct Cloud Firestore REST
  await syncToFirestoreRest(id, {
    status: 'dikerjakan',
    claimedBy: userName,
    claimedAt: now
  }, ['status', 'claimedBy', 'claimedAt']);

  return updatedItem;
}

/**
 * Selesaikan complain (ubah status ke 'selesai' dan simpan bukti)
 */
async function resolveComplain(id, evidenceUrl) {
  const now = new Date().toISOString();
  let updatedItem = null;

  // 1. Update di local storage
  const list = getLocalComplaints();
  const item = list.find(c => c.id === id);
  if (item) {
    item.status = 'selesai';
    item.resolvedAt = now;
    item.evidenceUrl = evidenceUrl;
    saveLocalComplaints(list);
    updatedItem = item;
  }

  // 2. Update via Admin SDK jika aktif
  if (isFirebaseReady && db) {
    try {
      await db.collection('complaints').doc(id).update({
        status: 'selesai',
        resolvedAt: now,
        evidenceUrl: evidenceUrl
      });
    } catch (err) {
      console.error('Error updating resolve in Firestore Admin:', err.message);
    }
  }

  // 3. SELALU sinkronkan ke Direct Cloud Firestore REST
  await syncToFirestoreRest(id, {
    status: 'selesai',
    resolvedAt: now,
    evidenceUrl: evidenceUrl
  }, ['status', 'resolvedAt', 'evidenceUrl']);

  return updatedItem;
}

/**
 * Kirim Push Notification FCM ke seluruh user yang terinstall SuperApp MTG
 */
async function sendPushNotification(complain) {
  if (!isFirebaseReady || !messaging) {
    console.log(`📣 [Notifikasi Simulasi] FCM belum dikonfigurasi. Pesan notifikasi:`);
    console.log(`   🚨 Complain Masuk: ${complain.hub}`);
    console.log(`   Inv: ${complain.invoice} - ${complain.description.substring(0, 60)}`);
    return { success: false, reason: 'Firebase not configured' };
  }

  const isCancel = complain.type === 'cancel' ||
    /cancel|batal|dibatalkan/i.test(complain.title || '') ||
    /cancel|batal|dibatalkan/i.test(complain.description || '') ||
    /cancel|batal|dibatalkan/i.test(complain.rawText || '');

  const notifTitle = isCancel
    ? `🚫 CANCEL ORDER: ${complain.hub || 'Hub MTG Menteng'}`
    : `🚨 Complain Baru: ${complain.hub || 'Hub MTG Menteng'}`;

  const notifPayload = {
    title: notifTitle,
    body: `Inv: ${complain.invoice} | ${complain.description.substring(0, 80)}`
  };

  if (complain.productImageUrl && complain.productImageUrl.startsWith('http')) {
    notifPayload.imageUrl = complain.productImageUrl;
  }

  const dataPayload = {
    action: 'open_complain',
    type: isCancel ? 'cancel' : 'complain',
    complain_id: String(complain.id),
    hub: String(complain.hub),
    invoice: String(complain.invoice),
    sender: String(complain.sender),
    title: notifTitle,
    description: String(complain.description || ''),
    timestamp: String(complain.createdAt)
  };

  if (complain.productImageUrl) {
    dataPayload.product_image_url = String(complain.productImageUrl);
  }

  const message = {
    topic: FCM_TOPIC,
    notification: notifPayload,
    data: dataPayload,
    android: {
      priority: 'high',
      notification: {
        channelId: 'complain_alerts',
        sound: 'default',
        color: isCancel ? '#ef4444' : '#f59e0b',
        defaultVibrateTimings: true,
        defaultSound: true,
        priority: 'max',
        visibility: 'public',
        notificationCount: 1,
        ...(complain.productImageUrl && complain.productImageUrl.startsWith('http')
          ? { imageUrl: complain.productImageUrl }
          : {})
      }
    }
  };

  try {
    const response = await messaging.send(message);
    console.log(`🚀 [FCM] Push Notification terkirim ke topic "${FCM_TOPIC}":`, response);
    return { success: true, messageId: response };
  } catch (err) {
    if (err.message && (err.message.includes('Invalid JWT Signature') || err.message.includes('invalid_grant'))) {
      console.error('\n🚨 [FCM CRITICAL] Private Key Service Account di firebase-service-account.json TIDAK VALID / TELAH DI-REVOKE DI GOOGLE CLOUD!');
      console.error('👉 Solusi Cepat: Buka Firebase Console (project: complain-m) -> Project Settings -> Service accounts -> Klik "Generate New Private Key", lalu timpa file wa-bot-webhook/firebase-service-account.json.\n');
    } else {
      console.error('❌ [FCM] Gagal mengirim Push Notification:', err.message);
    }
    return { success: false, error: err.message };
  }
}

/**
 * Cek status kesehatan koneksi FCM Admin SDK (dryRun)
 */
async function checkFcmHealth() {
  if (!isFirebaseReady || !messaging) {
    return {
      status: 'uninitialized',
      ready: false,
      reason: 'File credentials firebase-service-account.json belum dimuat atau gagal inisialisasi'
    };
  }
  try {
    const dryRunRes = await messaging.send({
      topic: FCM_TOPIC,
      data: { ping: 'health_check', timestamp: String(Date.now()) }
    }, true);
    return {
      status: 'healthy',
      ready: true,
      topic: FCM_TOPIC,
      projectId: FIRESTORE_PROJECT_ID,
      message: 'Autentikasi Firebase FCM Admin SDK 100% Aktif & Sehat',
      response: dryRunRes
    };
  } catch (err) {
    const isKeyRevoked = err.message && (err.message.includes('invalid_grant') || err.message.includes('Invalid JWT'));
    return {
      status: 'auth_error',
      ready: false,
      topic: FCM_TOPIC,
      projectId: FIRESTORE_PROJECT_ID,
      error: err.message,
      solution: isKeyRevoked
        ? 'Private key di firebase-service-account.json telah di-revoke/kedaluwarsa di Firebase Console. Harap generate private key baru di https://console.firebase.google.com/project/complain-m/settings/serviceaccounts/adminsdk'
        : err.message
    };
  }
}

/**
 * Hapus satu complain berdasarkan ID
 */
async function deleteComplain(id) {
  let deleted = false;
  // 1. Hapus dari local storage
  const list = getLocalComplaints();
  const idx = list.findIndex(c => c.id === id);
  if (idx >= 0) {
    list.splice(idx, 1);
    saveLocalComplaints(list);
    deleted = true;
  }

  // 2. Hapus dari Firestore via Admin SDK jika aktif
  if (isFirebaseReady && db) {
    try {
      await db.collection('complaints').doc(id).delete();
      deleted = true;
    } catch (err) {
      console.error('Error deleting complain from Firestore Admin:', err.message);
    }
  }

  // 3. SELALU hapus dari Direct Cloud Firestore REST
  await deleteFromFirestoreRest(id);
  deleted = true;

  return deleted;
}

/**
 * Hapus seluruh complain yang sudah berstatus 'selesai'
 */
async function clearResolvedComplaints() {
  const list = getLocalComplaints();
  const resolvedIds = list.filter(c => c.status === 'selesai').map(c => c.id);
  const remaining = list.filter(c => c.status !== 'selesai');
  saveLocalComplaints(remaining);

  if (isFirebaseReady && db && resolvedIds.length > 0) {
    try {
      const batch = db.batch();
      resolvedIds.forEach(id => {
        batch.delete(db.collection('complaints').doc(id));
      });
      await batch.commit();
      console.log(`🧹 [Firestore Admin] ${resolvedIds.length} complain berstatus selesai dibersihkan.`);
    } catch (err) {
      console.error('Error clearing resolved in Firestore Admin:', err.message);
    }
  }

  // Bersihkan juga di Cloud Firestore REST
  for (const id of resolvedIds) {
    await deleteFromFirestoreRest(id);
  }

  return { clearedCount: resolvedIds.length, remainingCount: remaining.length };
}

/**
 * Hapus seluruh data complain (Clear All Database)
 */
async function clearAllComplaints() {
  const list = getLocalComplaints();
  const count = list.length;
  const allIds = list.map(c => c.id);
  saveLocalComplaints([]);

  if (isFirebaseReady && db) {
    try {
      const snapshot = await db.collection('complaints').get();
      const batch = db.batch();
      snapshot.forEach(doc => {
        batch.delete(doc.ref);
      });
      await batch.commit();
      console.log(`🧹 [Firestore Admin] Seluruh database complain (${count} item) berhasil di-reset.`);
    } catch (err) {
      console.error('Error clearing all in Firestore Admin:', err.message);
    }
  }

  // Bersihkan di Cloud Firestore REST
  for (const id of allIds) {
    await deleteFromFirestoreRest(id);
  }

  return { clearedCount: count };
}

// Inisialisasi saat modul dimuat
initFirebase();

module.exports = {
  isFirebaseReady: () => isFirebaseReady,
  saveComplain,
  getAllComplaints,
  claimComplain,
  resolveComplain,
  deleteComplain,
  clearResolvedComplaints,
  clearAllComplaints,
  sendPushNotification,
  checkFcmHealth,
  FCM_TOPIC
};
