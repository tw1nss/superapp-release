/**
 * server.js - GoWA Webhook Server & Complain API untuk SuperApp MTG
 *
 * Menerima webhook pesan masuk dari GoWA WhatsApp Gateway di VPS,
 * melakukan parsing pesan trigger Hub MTG Menteng / Hub Astro Menteng,
 * menyimpan complain ke Firestore/Local DB, dan mengirimkan FCM Push Notification.
 */

const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');
const { parseComplainMessage } = require('./parser');
const {
  isFirebaseReady,
  saveComplain,
  getAllComplaints,
  claimComplain,
  resolveComplain,
  deleteComplain,
  clearResolvedComplaints,
  clearAllComplaints,
  sendPushNotification,
  FCM_TOPIC
} = require('./firebase-service');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3100;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || '';

// Middleware
app.use(cors());
// Tingkatkan limit json untuk mendukung upload base64 screenshot bukti
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Request logger
app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleTimeString('id-ID')}] ${req.method} ${req.url}`);
  next();
});

// ─── Health & Status Endpoint ───
app.get('/health', async (req, res) => {
  const complaints = await getAllComplaints();
  res.json({
    status: 'ok',
    service: 'SuperApp MTG - GoWA Complain Webhook Bot',
    firebaseConnected: isFirebaseReady(),
    fcmTopic: FCM_TOPIC,
    totalComplaints: complaints.length,
    timestamp: new Date().toISOString()
  });
});

// ─── Telemetry: Lihat Payload Webhook Terakhir ───
app.get(['/api/latest-webhook', '/api/latest-payload'], (req, res) => {
  try {
    const payloadFile = path.join(__dirname, 'latest_webhook_payload.json');
    if (fs.existsSync(payloadFile)) {
      const content = fs.readFileSync(payloadFile, 'utf8');
      return res.type('application/json').send(content);
    }
    res.json({ message: 'Belum ada payload webhook WhatsApp yang terekam' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── 1. GoWA Webhook Receiver ───
app.post('/webhook', async (req, res) => {
  try {
    // Opsional: Validasi secret token jika dikonfigurasi di GoWA
    if (WEBHOOK_SECRET) {
      const headerSecret = req.headers['x-webhook-secret'] || req.query.secret;
      if (headerSecret !== WEBHOOK_SECRET) {
        return res.status(401).json({ error: 'Unauthorized webhook request' });
      }
    }

    const body = req.body || {};

    // Simpan payload mentah terakhir untuk transparansi & debugging
    try {
      fs.writeFileSync(path.join(__dirname, 'latest_webhook_payload.json'), JSON.stringify(body, null, 2), 'utf8');
    } catch (e) {}

    // Universal recursive extractor untuk mengekstrak teks dari berbagai struktur GoWA / whatsmeow
    function findTextMessage(obj, depth = 0) {
      if (!obj || depth > 10) return '';
      if (typeof obj === 'string') return obj;
      if (typeof obj !== 'object') return '';

      // 1. Prioritaskan field caption (karena pesan gambar meletakkan teks keluhan di caption)
      const targetKeys = ['caption', 'conversation', 'text', 'message', 'body', 'content', 'msg', 'description', 'comment'];
      for (const key of Object.keys(obj)) {
        const lowerKey = key.toLowerCase();
        if (targetKeys.includes(lowerKey)) {
          if (typeof obj[key] === 'string' && obj[key].trim().length > 0) {
            return obj[key];
          }
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            const nested = findTextMessage(obj[key], depth + 1);
            if (nested) return nested;
          }
        }
      }

      // 2. Jelajahi wrapper protokol WhatsApp (ephemeral, viewOnce, document, image)
      const wrappers = [
        'ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2',
        'documentWithCaptionMessage', 'imageMessage', 'documentMessage', 'videoMessage'
      ];
      for (const w of wrappers) {
        if (obj[w] && typeof obj[w] === 'object') {
          const nested = findTextMessage(obj[w], depth + 1);
          if (nested) return nested;
        }
      }

      for (const key of Object.keys(obj)) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const nested = findTextMessage(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      return '';
    }

    function findField(obj, candidateKeys, depth = 0) {
      if (!obj || typeof obj !== 'object' || depth > 5) return '';
      for (const key of Object.keys(obj)) {
        if (candidateKeys.includes(key.toLowerCase())) {
          if (typeof obj[key] === 'string' || typeof obj[key] === 'number') {
            return String(obj[key]);
          }
        }
      }
      const containers = ['data', 'key', 'message', 'info', 'msg', 'payload'];
      for (const c of containers) {
        if (obj[c] && typeof obj[c] === 'object') {
          const found = findField(obj[c], candidateKeys, depth + 1);
          if (found) return found;
        }
      }
      return '';
    }

    // Helper pencarian file media GoWA di berbagai direktori VPS & local server
    function resolveLocalMediaFile(relPath) {
      if (!relPath || typeof relPath !== 'string') return null;
      const clean = relPath.replace(/^[\/\\]+/, '');
      const candidateBases = [
        process.cwd(),
        __dirname,
        path.resolve(__dirname, '..'),
        path.resolve(__dirname, '..', 'go-whatsapp-web-multidevice'),
        path.resolve(__dirname, '..', 'gowa'),
        '/root/go-whatsapp-web-multidevice',
        '/root/gowa',
        '/var/www/gowa',
        '/opt/gowa',
        '/root'
      ];

      for (const base of candidateBases) {
        try {
          const fullPath = path.resolve(base, clean);
          if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
            const buf = fs.readFileSync(fullPath);
            if (buf.length > 0) {
              const ext = path.extname(fullPath).toLowerCase();
              const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
              console.log(`📸 [MEDIA] File gambar ditemukan di disk: ${fullPath} (${buf.length} bytes)`);
              return `data:${mime};base64,${buf.toString('base64')}`;
            }
          }
        } catch (_) {}
      }
      return null;
    }

    // Helper fetch media dari endpoint static server GoWA via HTTP port lokal
    async function fetchGoWAMediaHttp(relPath) {
      if (!relPath || typeof relPath !== 'string') return null;
      const clean = relPath.replace(/^\/+/, '');
      const candidateHosts = [
        process.env.GOWA_URL,
        'http://127.0.0.1:3000',
        'http://localhost:3000',
        'http://127.0.0.1:8080',
        'http://127.0.0.1:8000'
      ].filter(Boolean);

      for (const host of candidateHosts) {
        try {
          const fetchUrl = `${host.replace(/\/+$/, '')}/${clean}`;
          const headers = {};
          if (process.env.GOWA_BASIC_AUTH) {
            headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
          }
          const res = await fetch(fetchUrl, { headers, signal: AbortSignal.timeout(3000) });
          if (res.ok) {
            const arrBuf = await res.arrayBuffer();
            const buf = Buffer.from(arrBuf);
            if (buf.length > 0) {
              const mime = res.headers.get('content-type') || 'image/jpeg';
              console.log(`📸 [MEDIA] Berhasil download gambar via GoWA HTTP (${fetchUrl}): ${buf.length} bytes`);
              return `data:${mime};base64,${buf.toString('base64')}`;
            }
          }
        } catch (_) {}
      }
      return null;
    }

    // Universal extractor untuk mengekstrak foto/gambar produk dari payload GoWA / whatsmeow
    async function findImageMedia(obj, depth = 0) {
      if (!obj || depth > 10) return null;

      async function toBase64Jpeg(val) {
        if (!val) return null;
        if (typeof val === 'string') {
          const s = val.trim();
          if (s.startsWith('data:image/')) {
            return s;
          }

          // 1. Cek file lokal di disk VPS
          const fromDisk = resolveLocalMediaFile(s);
          if (fromDisk) return fromDisk;

          // 2. Cek jika URL http/https — fetch langsung jika bukan WhatsApp CDN
          if (s.startsWith('http://') || s.startsWith('https://')) {
            if (!s.includes('whatsapp.net') && !s.includes('mmg.whatsapp')) {
              try {
                const fetchRes = await fetch(s, { signal: AbortSignal.timeout(5000) });
                if (fetchRes.ok) {
                  const cType = fetchRes.headers.get('content-type') || '';
                  if (cType.startsWith('image/') || cType.startsWith('application/octet')) {
                    const arrayBuf = await fetchRes.arrayBuffer();
                    const buf = Buffer.from(arrayBuf);
                    if (buf.length > 0) {
                      const mime = cType.startsWith('image/') ? cType : 'image/jpeg';
                      return `data:${mime};base64,${buf.toString('base64')}`;
                    }
                  }
                }
              } catch (e) {
                console.log(`⚠️ Gagal fetch media URL: ${s.substring(0, 80)} — ${e.message}`);
              }
              return s;
            }
          }

          // 3. Cek jika path lokal relatif GoWA (contoh: statics/media/xxx.jpg atau /statics/xxx)
          if (s.startsWith('/') || s.startsWith('statics') || s.includes('statics/')) {
            const fromHttp = await fetchGoWAMediaHttp(s);
            if (fromHttp) return fromHttp;
          }

          // 4. Cek string base64 murni
          const clean = s.replace(/\s+/g, '');
          if (clean.length > 50 && /^[A-Za-z0-9+/=]+$/.test(clean.substring(0, 100))) {
            return `data:image/jpeg;base64,${clean}`;
          }
          return null;
        }

        if (typeof Buffer !== 'undefined' && Buffer.isBuffer(val)) {
          return `data:image/jpeg;base64,${val.toString('base64')}`;
        }
        if (Array.isArray(val) && val.length > 30) {
          return `data:image/jpeg;base64,${Buffer.from(val).toString('base64')}`;
        }
        if (typeof val === 'object' && val !== null) {
          if (val.type === 'Buffer' && Array.isArray(val.data)) {
            return `data:image/jpeg;base64,${Buffer.from(val.data).toString('base64')}`;
          }
          // Objek { path: "statics/media/..." } dari GoWA buildAutoDownloadPayload
          if (val.path && typeof val.path === 'string') {
            const fromDisk = resolveLocalMediaFile(val.path);
            if (fromDisk) return fromDisk;
            const fromHttp = await fetchGoWAMediaHttp(val.path);
            if (fromHttp) return fromHttp;
          }
          if (val.url && typeof val.url === 'string' && !val.url.includes('whatsapp.net')) {
            const fromUrl = await toBase64Jpeg(val.url);
            if (fromUrl) return fromUrl;
          }
          if (val.jpegThumbnail) {
            const thumb = await toBase64Jpeg(val.jpegThumbnail);
            if (thumb) return thumb;
          }
        }
        return null;
      }

      // 1. WhatsApp media containers
      const mediaContainers = ['imageMessage', 'documentMessage', 'videoMessage', 'stickerMessage'];
      for (const mc of mediaContainers) {
        if (obj[mc] && typeof obj[mc] === 'object') {
          const m = obj[mc];
          if (m.jpegThumbnail) {
            const thumb = await toBase64Jpeg(m.jpegThumbnail);
            if (thumb) return thumb;
          }
          if (m.url && typeof m.url === 'string' && m.url.startsWith('http') && !m.url.includes('whatsapp.net')) {
            const resolved = await toBase64Jpeg(m.url.trim());
            if (resolved) return resolved;
          }
          if (m.mediaUrl || m.media_url || m.file || m.base64 || m.image || m.path) {
            const direct = await toBase64Jpeg(m.mediaUrl || m.media_url || m.file || m.base64 || m.image || m.path);
            if (direct) return direct;
          }
        }
      }

      // 2. Direct candidate keys (GoWA + whatsmeow + generic)
      const targetKeys = [
        'path', 'filepath', 'file_path', 'mediapath', 'media_path',
        'productimageurl', 'imageurl', 'image_url', 'photourl', 'photo_url',
        'image', 'photo', 'picture', 'media_url', 'mediaurl', 'file_url', 'fileurl',
        'url', 'uri', 'jpegthumbnail', 'thumbnail', 'base64', 'media', 'attachment',
        'media_data', 'file_data', 'file', 'sticker', 'document'
      ];

      for (const key of Object.keys(obj)) {
        const lowerKey = key.toLowerCase();
        if (targetKeys.includes(lowerKey)) {
          const val = obj[key];
          const parsed = await toBase64Jpeg(val);
          if (parsed) return parsed;
          if (typeof val === 'object' && val !== null) {
            const nested = await findImageMedia(val, depth + 1);
            if (nested) return nested;
          }
        }
      }

      // 3. Jelajahi nested data/message
      for (const key of ['data', 'message', 'payload', 'msg', 'body', 'ephemeralMessage', 'viewOnceMessage', 'quotedMessage', 'contextInfo']) {
        if (obj[key] && typeof obj[key] === 'object') {
          const nested = await findImageMedia(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      for (const key of Object.keys(obj)) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const nested = await findImageMedia(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      return null;
    }

    const rawMessage = findTextMessage(body).trim();
    let productImageUrl = await findImageMedia(body);
    const messageId = findField(body, ['id', 'message_id', 'msg_id', 'stanza_id']);
    const fromGroup = findField(body, ['chat_id', 'remotejid', 'jid']);
    const senderPhone = findField(body, ['from', 'sender', 'sender_phone', 'participant']);
    const senderName = findField(body, ['push_name', 'pushname', 'sender_name', 'name', 'notify']);
    const timestamp = Date.now();

    // ─── Proactive GoWA Media Download API Fallback ───
    // Jika belum dapat gambar tetapi terindikasi ada media gambar dengan messageId
    if (!productImageUrl && messageId) {
      const isMediaCandidate = Boolean(
        findField(body, ['media_type', 'mediatype', 'type']) === 'image' ||
        JSON.stringify(body).includes('imageMessage') ||
        JSON.stringify(body).includes('mmg.whatsapp.net') ||
        body?.payload?.image ||
        body?.image
      );

      if (isMediaCandidate) {
        console.log(`🔄 [GoWA Download API] Mencoba request unduh media untuk messageId ${messageId}...`);
        const candidateHosts = [
          process.env.GOWA_URL,
          'http://127.0.0.1:3000',
          'http://localhost:3000',
          'http://127.0.0.1:8080',
          'http://127.0.0.1:8000'
        ].filter(Boolean);

        const chatJid = fromGroup || senderPhone || '';
        const cleanPhone = chatJid.replace(/@.*$/, '');
        const phoneVariants = [chatJid, cleanPhone].filter(Boolean);

        for (const host of candidateHosts) {
          if (productImageUrl) break;
          for (const ph of phoneVariants) {
            try {
              const downloadUrl = `${host.replace(/\/+$/, '')}/message/${messageId}/download?phone=${encodeURIComponent(ph)}`;
              const headers = {};
              if (process.env.GOWA_BASIC_AUTH) {
                headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
              }
              const dlRes = await fetch(downloadUrl, { headers, signal: AbortSignal.timeout(6000) });
              if (dlRes.ok) {
                const dlJson = await dlRes.json();
                const resObj = dlJson.results || dlJson.data || dlJson;
                const downloadedPath = resObj.file_path || resObj.filePath || resObj.path;
                const downloadedUrl = resObj.file_url || resObj.fileUrl || resObj.url;

                if (downloadedPath) {
                  const fromDisk = resolveLocalMediaFile(downloadedPath);
                  if (fromDisk) {
                    productImageUrl = fromDisk;
                    break;
                  }
                }
                if (downloadedUrl) {
                  const fromHttp = await fetchGoWAMediaHttp(downloadedUrl);
                  if (fromHttp) {
                    productImageUrl = fromHttp;
                    break;
                  }
                }
              }
            } catch (dlErr) {
              // Lanjut ke varian/host berikutnya
            }
          }
        }
      }
    }

    // ─── Instant Thumbnail Fallback ───
    // Jika belum dapat file penuh, cari jpegThumbnail bawaan WhatsApp protobuf di seluruh payload
    if (!productImageUrl) {
      function findAnyThumbnail(o, d = 0) {
        if (!o || d > 8 || typeof o !== 'object') return null;
        for (const k of Object.keys(o)) {
          const lk = k.toLowerCase();
          if (lk === 'jpegthumbnail' || lk === 'thumbnail') {
            const v = o[k];
            if (typeof v === 'string' && v.trim().length > 20) {
              const s = v.trim();
              return s.startsWith('data:image/') ? s : `data:image/jpeg;base64,${s.replace(/\s+/g, '')}`;
            }
            if (Buffer.isBuffer(v)) {
              return `data:image/jpeg;base64,${v.toString('base64')}`;
            }
            if (Array.isArray(v) && v.length > 20) {
              return `data:image/jpeg;base64,${Buffer.from(v).toString('base64')}`;
            }
            if (v && v.type === 'Buffer' && Array.isArray(v.data)) {
              return `data:image/jpeg;base64,${Buffer.from(v.data).toString('base64')}`;
            }
          }
        }
        for (const k of Object.keys(o)) {
          if (o[k] && typeof o[k] === 'object') {
            const found = findAnyThumbnail(o[k], d + 1);
            if (found) return found;
          }
        }
        return null;
      }
      const thumb = findAnyThumbnail(body);
      if (thumb) {
        console.log(`📸 [MEDIA] Berhasil mengekstrak thumbnail JPEG dari protobuf WhatsApp (${thumb.substring(0, 35)}...)`);
        productImageUrl = thumb;
      }
    }

    console.log(`🔍 [DEBUG] rawMessage: "${(rawMessage || '').substring(0, 60)}" | image: ${productImageUrl ? 'YES' : 'NO'} | from: ${senderPhone} | group: ${fromGroup} | name: ${senderName}`);

    // Jika pesan teks kosong tapi terdapat foto, hanya proses jika Direct Chat (bukan di grup multi-hub)
    let effectiveMessage = rawMessage;
    const isGroupChat = Boolean(fromGroup && fromGroup.endsWith('@g.us'));
    if (!effectiveMessage && productImageUrl) {
      if (!isGroupChat) {
        effectiveMessage = `Complain Hub MTG Menteng\nInv: INV-FOTO-${Date.now().toString().slice(-6)}\nDetail: Keluhan foto produk dari WhatsApp (Japri Bot)\nPengirim: ${senderName || 'Customer'}`;
        console.log('📸 [Direct Chat] Pesan foto tanpa caption ke nomor bot terdeteksi, membuat tiket complain otomatis.');
      } else {
        console.log('ℹ️ [Group Chat] Pesan foto tanpa teks di grup diabaikan (karena grup multi-hub wajib mencantumkan Hub MTG Menteng).');
      }
    }

    if (!effectiveMessage) {
      console.log(`ℹ️ [Event: ${body.event || 'update'}] Diabaikan (bukan pesan teks atau foto)`);
      console.log(`🔎 Struktur payload diterima:`, JSON.stringify(body).substring(0, 350));
      return res.status(200).json({ status: 'ignored', reason: 'No message content or media' });
    }

    console.log(`📩 Pesan WA Diterima: "${rawMessage.substring(0, 70).replace(/\n/g, ' ')}..." [Dari: ${senderName || senderPhone || 'Unknown'}]`);
    if (productImageUrl) {
      console.log(`📸 Foto Produk Terlampir: Ya (${productImageUrl.substring(0, 30)}...)`);
    }

    // Parse pesan menggunakan parser
    const meta = {
      messageId,
      fromGroup,
      senderPhone,
      senderName,
      timestamp,
      productImageUrl
    };

    const customTriggers = process.env.CUSTOM_TRIGGERS
      ? process.env.CUSTOM_TRIGGERS.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const complain = parseComplainMessage(effectiveMessage, meta, customTriggers);

    if (!complain) {
      console.log(`ℹ️ Diabaikan (bukan pesan complain/trigger): "${effectiveMessage.substring(0, 50).replace(/\n/g, ' ')}"`);
      return res.status(200).json({
        status: 'ignored',
        reason: 'Pesan tidak mengandung trigger complain atau nomor invoice'
      });
    }

    console.log(`🎯 COMPLAIN TERDETEKSI! Merekam task: [${complain.hub}] ${complain.invoice} - ${complain.description.substring(0, 50)}`);

    // Simpan ke Firestore / Local DB
    await saveComplain(complain);

    // Kirim Push Notification FCM ke seluruh user SuperApp MTG
    const notifResult = await sendPushNotification(complain);

    return res.status(201).json({
      status: 'success',
      message: 'Complain berhasil diproses dan notifikasi telah dikirim',
      complain,
      notification: notifResult
    });

  } catch (err) {
    console.error('❌ Error handling webhook:', err);
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
});

// ─── 2. REST API: Get All Complaints ───
app.get('/api/complaints', async (req, res) => {
  try {
    const status = req.query.status || 'semua';
    const list = await getAllComplaints(status);
    res.json({
      success: true,
      count: list.length,
      data: list
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 3. REST API: Claim Complain ───
app.post('/api/complaints/:id/claim', async (req, res) => {
  try {
    const { id } = req.params;
    const { userName = 'Tim Warehouse MTG' } = req.body;
    const updated = await claimComplain(id, userName);

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4. REST API: Resolve Complain (Upload Bukti Selesai) ───
app.post('/api/complaints/:id/resolve', async (req, res) => {
  try {
    const { id } = req.params;
    const { evidenceUrl } = req.body;

    if (!evidenceUrl) {
      return res.status(400).json({ success: false, error: 'Bukti screenshot (evidenceUrl) wajib disertakan' });
    }

    const updated = await resolveComplain(id, evidenceUrl);

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4b. REST API Admin: Delete Single Complain ───
app.delete('/api/complaints/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const success = await deleteComplain(id);
    if (!success) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }
    res.json({ success: true, message: `Complain ${id} berhasil dihapus` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4c. REST API Admin: Clear Resolved Complaints ───
app.post('/api/complaints/clear-resolved', async (req, res) => {
  try {
    const result = await clearResolvedComplaints();
    res.json({
      success: true,
      message: `${result.clearedCount} complain berstatus selesai berhasil dibersihkan`,
      data: result
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4d. REST API Admin: Clear All Complaints (Reset) ───
app.post('/api/complaints/clear-all', async (req, res) => {
  try {
    const { pin = '' } = req.body;
    // Simple admin PIN verification
    const expectedPin = process.env.ADMIN_PIN || '1234';
    if (String(pin).trim() !== String(expectedPin).trim()) {
      return res.status(403).json({ success: false, error: 'PIN Admin tidak valid' });
    }

    const result = await clearAllComplaints();
    res.json({
      success: true,
      message: `Seluruh data complain (${result.clearedCount} item) berhasil di-reset`,
      data: result
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4e. REST API Admin: Inspect Latest Webhook Payload ───
app.get('/api/latest-webhook', (req, res) => {
  const payloadPath = path.join(__dirname, 'latest_webhook_payload.json');
  if (fs.existsSync(payloadPath)) {
    try {
      const data = JSON.parse(fs.readFileSync(payloadPath, 'utf8'));
      return res.json({ success: true, payload: data });
    } catch (e) {
      return res.status(500).json({ success: false, error: e.message });
    }
  }
  res.json({ success: false, message: 'Belum ada webhook yang diterima' });
});

// ─── 5. Endpoint Simulasi Complain (Untuk Test Tanpa WA) ───
app.post('/api/simulate-complain', async (req, res) => {
  try {
    const {
      hub = 'Hub MTG Menteng',
      invoice = 'INV-SIMULASI-' + Math.floor(1000 + Math.random() * 9000),
      sender = 'Tester QC Menteng',
      description = 'Simulasi keluhan: Kardus basah dan bocor di area packing',
      messageText,
      productImageUrl,
      image,
      photo
    } = req.body;

    const img = productImageUrl || image || photo || null;

    let complain;
    if (messageText) {
      complain = parseComplainMessage(messageText, { senderName: sender, productImageUrl: img });
    }

    if (!complain) {
      const now = new Date();
      complain = {
        id: `cpl-${now.toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).substring(2, 7)}`,
        hub,
        invoice,
        sender,
        description,
        productImageUrl: img,
        status: 'baru',
        createdAt: now.toISOString(),
        claimedBy: null,
        claimedAt: null,
        resolvedAt: null,
        evidenceUrl: null,
        source: {
          platform: 'simulation',
          gateway: 'gowa-simulator',
          timestamp: Math.floor(now.getTime() / 1000)
        }
      };
    }

    await saveComplain(complain);
    const notif = await sendPushNotification(complain);

    res.json({
      success: true,
      message: 'Simulasi complain berhasil dibuat dan notifikasi dikirim',
      complain,
      notification: notif
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`\n══════════════════════════════════════════════════════════`);
  console.log(`🚀 GoWA Complain Webhook Server running on port ${PORT}`);
  console.log(`📡 Webhook URL   : http://localhost:${PORT}/webhook`);
  console.log(`📋 API Endpoint  : http://localhost:${PORT}/api/complaints`);
  console.log(`🧪 Test Simulate : POST http://localhost:${PORT}/api/simulate-complain`);
  console.log(`══════════════════════════════════════════════════════════\n`);
});
