/**
 * server.js - GoWA Webhook Server & Complain API untuk SuperApp MTG
 *
 * Menerima webhook pesan masuk dari GoWA WhatsApp Gateway di VPS,
 * melakukan parsing pesan trigger Hub MTG Menteng / Hub Astro Menteng,
 * menyimpan complain ke Firestore/Local DB, dan mengirimkan FCM Push Notification.
 */

const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');
const { safeFetch } = require('./safe_fetch');
const { parseComplainMessage } = require('./parser');
const {
  isFirebaseReady,
  saveComplain,
  getAllComplaints,
  claimComplain,
  resolveComplain,
  deleteComplain,
  clearResolvedComplaints,
  clearAllComplaints,
  sendPushNotification,
  checkFcmHealth,
  FCM_TOPIC
} = require('./firebase-service');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3100;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || '';

// Middleware
app.use(cors());
// Tingkatkan limit json untuk mendukung upload base64 screenshot bukti
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Request logger
app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleTimeString('id-ID')}] ${req.method} ${req.url}`);
  next();
});

// ─── Health & Status Endpoint ───
app.get('/health', async (req, res) => {
  const complaints = await getAllComplaints();
  res.json({
    status: 'ok',
    service: 'SuperApp MTG - GoWA Complain Webhook Bot',
    firebaseConnected: isFirebaseReady(),
    fcmTopic: FCM_TOPIC,
    totalComplaints: complaints.length,
    timestamp: new Date().toISOString()
  });
});

// ─── Telemetry: Lihat Payload Webhook Terakhir ───
app.get(['/api/latest-webhook', '/api/latest-payload'], (req, res) => {
  try {
    const payloadFile = path.join(__dirname, 'latest_webhook_payload.json');
    if (fs.existsSync(payloadFile)) {
      const content = fs.readFileSync(payloadFile, 'utf8');
      return res.type('application/json').send(content);
    }
    res.json({ message: 'Belum ada payload webhook WhatsApp yang terekam' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Cache & Helper Grup CX <> QA Fresh Discussion ───
const groupNameCache = new Map();

/**
 * Memeriksa apakah nama atau JID grup cocok dengan grup CX <> QA Fresh Discussion
 */
function matchesCxQaGroup(nameOrJid) {
  if (!nameOrJid || typeof nameOrJid !== 'string') return false;
  const targetConfigName = (process.env.CX_GROUP_NAME || 'CX <> QA Fresh Discussion').toLowerCase().trim();
  const targetConfigJid = (process.env.CX_GROUP_JID || '').toLowerCase().trim();

  const str = nameOrJid.toLowerCase().trim();

  // 1. Cocokkan dengan configured JID
  if (targetConfigJid && str === targetConfigJid) return true;

  // 2. Cocokkan langsung dengan target config name
  if (str === targetConfigName) return true;

  // 3. Normalisasi karakter tanda baca & simbol
  const cleanStr = str.replace(/[^a-z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const cleanTarget = targetConfigName.replace(/[^a-z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  if (cleanStr === cleanTarget) return true;

  // 4. Cek kombinasi kata kunci utama: "cx" DAN ("fresh discussion" atau "qa fresh")
  const hasCx = cleanStr.includes('cx');
  const hasFresh = cleanStr.includes('fresh');
  const hasDiscussion = cleanStr.includes('discussion') || cleanStr.includes('diskusi');
  const hasQa = cleanStr.includes('qa');

  if (hasCx && hasFresh && (hasDiscussion || hasQa)) return true;
  if (cleanStr.includes('cx qa') || cleanStr.includes('cx mtg') || cleanStr.includes('cx fresh')) return true;

  return false;
}

/**
 * Dapatkan nama grup dari payload, cache, atau query GoWA API
 */
async function resolveGroupName(jid, rawPayload, findFieldFn) {
  if (!jid || typeof jid !== 'string' || !jid.endsWith('@g.us')) return '';

  // 1. Cek di payload langsung
  if (findFieldFn && rawPayload) {
    const nameFromPayload = findFieldFn(rawPayload, [
      'group_name', 'groupname', 'chat_name', 'chatname',
      'subject', 'group_subject', 'title', 'group_title', 'name'
    ]);
    if (nameFromPayload && typeof nameFromPayload === 'string' && nameFromPayload.trim()) {
      groupNameCache.set(jid, nameFromPayload.trim());
      return nameFromPayload.trim();
    }
  }

  // 2. Cek di cache memori
  if (groupNameCache.has(jid)) {
    return groupNameCache.get(jid);
  }

  // 3. Coba query ke GoWA HTTP API
  const candidateHosts = [
    process.env.GOWA_URL,
    'http://127.0.0.1:3000',
    'http://localhost:3000',
    'http://127.0.0.1:8080',
    'http://127.0.0.1:8000'
  ].filter(Boolean);

  for (const host of candidateHosts) {
    try {
      const endpoints = [
        `${host.replace(/\/+$/, '')}/group/${jid}`,
        `${host.replace(/\/+$/, '')}/group/info?jid=${encodeURIComponent(jid)}`,
        `${host.replace(/\/+$/, '')}/user/my/groups`
      ];

      const headers = {};
      if (process.env.GOWA_BASIC_AUTH) {
        headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
      }

      for (const ep of endpoints) {
        try {
          const res = await safeFetch(ep, { headers, timeout: 2000 });
          if (res.ok) {
            const data = await res.json();
            const list = data.data || data.results || (Array.isArray(data) ? data : null);
            if (Array.isArray(list)) {
              for (const g of list) {
                const gJid = g.jid || g.id || g.JID;
                const gName = g.name || g.subject || g.Name;
                if (gJid && gName) {
                  groupNameCache.set(String(gJid), String(gName).trim());
                }
              }
              if (groupNameCache.has(jid)) {
                return groupNameCache.get(jid);
              }
            } else {
              const info = data.data || data.results || data;
              const gName = info.name || info.subject || info.title || info.Name;
              if (gName && typeof gName === 'string') {
                groupNameCache.set(jid, gName.trim());
                return gName.trim();
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}
  }

  return '';
}

// ─── 1. GoWA Webhook Receiver ───
app.post('/webhook', async (req, res) => {
  try {
    // Opsional: Validasi secret token jika dikonfigurasi di GoWA
    if (WEBHOOK_SECRET) {
      const headerSecret = req.headers['x-webhook-secret'] || req.query.secret;
      if (headerSecret !== WEBHOOK_SECRET) {
        return res.status(401).json({ error: 'Unauthorized webhook request' });
      }
    }

    const body = req.body || {};

    // Simpan payload mentah terakhir untuk transparansi & debugging
    try {
      fs.writeFileSync(path.join(__dirname, 'latest_webhook_payload.json'), JSON.stringify(body, null, 2), 'utf8');
    } catch (e) {}

    function findField(obj, candidateKeys, depth = 0) {
      if (!obj || typeof obj !== 'object' || depth > 6) return '';
      for (const key of Object.keys(obj)) {
        if (candidateKeys.includes(key.toLowerCase())) {
          if (typeof obj[key] === 'string' || typeof obj[key] === 'number') {
            return String(obj[key]);
          }
        }
      }
      const containers = ['data', 'key', 'message', 'info', 'msg', 'payload'];
      for (const c of containers) {
        if (obj[c] && typeof obj[c] === 'object') {
          const found = findField(obj[c], candidateKeys, depth + 1);
          if (found) return found;
        }
      }
      return '';
    }

    // ─── 0. DETEKSI & BLOKIR PESAN KELUAR DARI NOMOR BOT (OUTGOING / FROM ME) ───
    function checkIsFromMe(obj, depth = 0) {
      if (!obj || depth > 8 || typeof obj !== 'object') return false;

      const fromMeKeys = ['from_me', 'fromme', 'is_from_me', 'sent_by_me', 'isfromme'];
      for (const k of Object.keys(obj)) {
        if (fromMeKeys.includes(k.toLowerCase())) {
          if (obj[k] === true || obj[k] === 1 || obj[k] === 'true') return true;
        }
      }

      for (const k of ['key', 'payload', 'data', 'info', 'message', 'msg']) {
        if (obj[k] && typeof obj[k] === 'object') {
          if (checkIsFromMe(obj[k], depth + 1)) return true;
        }
      }
      return false;
    }

    const isFromMe = checkIsFromMe(body);
    const eventType = String(body.event || body.type || '').toLowerCase();
    const isOutboundEvent = eventType.includes('sent') || eventType.includes('outgoing') || eventType === 'message.ack';

    const deviceId = findField(body, ['device_id', 'deviceid', 'me', 'bot_phone', 'session_id']);
    const senderCandidate = findField(body, ['from', 'sender', 'sender_phone', 'participant']);
    
    let isSelfSender = false;
    if (deviceId && senderCandidate) {
      const cleanDev = deviceId.replace(/[^0-9]/g, '');
      const cleanSender = senderCandidate.replace(/[^0-9]/g, '');
      if (cleanDev && cleanSender && (cleanDev === cleanSender || cleanDev.endsWith(cleanSender) || cleanSender.endsWith(cleanDev))) {
        isSelfSender = true;
      }
    }

    if (isFromMe || isOutboundEvent || isSelfSender) {
      console.log(`ℹ️ [OUTGOING] Pesan dikirim oleh nomor bot sendiri (${senderCandidate || deviceId || 'Self'}), diabaikan.`);
      return res.status(200).json({ status: 'ignored', reason: 'Outgoing message sent by bot' });
    }

    // Universal recursive extractor untuk mengekstrak teks dari berbagai struktur GoWA / whatsmeow
    function findTextMessage(obj, depth = 0) {
      if (!obj || depth > 10) return '';
      if (typeof obj === 'string') return obj;
      if (typeof obj !== 'object') return '';

      // 1. Prioritaskan field caption (karena pesan gambar meletakkan teks keluhan di caption)
      const targetKeys = ['caption', 'conversation', 'text', 'message', 'body', 'content', 'msg', 'description', 'comment'];
      for (const key of Object.keys(obj)) {
        const lowerKey = key.toLowerCase();
        if (targetKeys.includes(lowerKey)) {
          if (typeof obj[key] === 'string' && obj[key].trim().length > 0) {
            return obj[key];
          }
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            const nested = findTextMessage(obj[key], depth + 1);
            if (nested) return nested;
          }
        }
      }

      // 2. Jelajahi wrapper protokol WhatsApp (ephemeral, viewOnce, document, image)
      const wrappers = [
        'ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2',
        'documentWithCaptionMessage', 'imageMessage', 'documentMessage', 'videoMessage'
      ];
      for (const w of wrappers) {
        if (obj[w] && typeof obj[w] === 'object') {
          const nested = findTextMessage(obj[w], depth + 1);
          if (nested) return nested;
        }
      }

      for (const key of Object.keys(obj)) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const nested = findTextMessage(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      return '';
    }

    // Helper pencarian file media GoWA di berbagai direktori VPS & local server
    function resolveLocalMediaFile(relPath) {
      if (!relPath || typeof relPath !== 'string') return null;
      const clean = relPath.replace(/^[\/\\]+/, '');
      const candidateBases = [
        process.cwd(),
        __dirname,
        path.resolve(__dirname, '..'),
        path.resolve(__dirname, '..', 'go-whatsapp-web-multidevice'),
        path.resolve(__dirname, '..', 'gowa'),
        '/root/go-whatsapp-web-multidevice',
        '/root/gowa',
        '/var/www/gowa',
        '/opt/gowa',
        '/root'
      ];

      for (const base of candidateBases) {
        try {
          const fullPath = path.resolve(base, clean);
          if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
            const buf = fs.readFileSync(fullPath);
            if (buf.length > 0) {
              const ext = path.extname(fullPath).toLowerCase();
              const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
              console.log(`📸 [MEDIA] File gambar ditemukan di disk: ${fullPath} (${buf.length} bytes)`);
              return `data:${mime};base64,${buf.toString('base64')}`;
            }
          }
        } catch (_) {}
      }
      return null;
    }

    // Helper fetch media dari endpoint static server GoWA via HTTP port lokal
    async function fetchGoWAMediaHttp(relPath) {
      if (!relPath || typeof relPath !== 'string') return null;
      const clean = relPath.replace(/^\/+/, '');
      const candidateHosts = [
        process.env.GOWA_URL,
        'http://127.0.0.1:3000',
        'http://localhost:3000',
        'http://127.0.0.1:8080',
        'http://127.0.0.1:8000'
      ].filter(Boolean);

      for (const host of candidateHosts) {
        try {
          const fetchUrl = `${host.replace(/\/+$/, '')}/${clean}`;
          const headers = {};
          if (process.env.GOWA_BASIC_AUTH) {
            headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
          }
          const res = await safeFetch(fetchUrl, { headers, timeout: 3000 });
          if (res.ok) {
            const arrBuf = await res.arrayBuffer();
            const buf = Buffer.from(arrBuf);
            if (buf.length > 0) {
              const mime = res.headers.get('content-type') || 'image/jpeg';
              console.log(`📸 [MEDIA] Berhasil download gambar via GoWA HTTP (${fetchUrl}): ${buf.length} bytes`);
              return `data:${mime};base64,${buf.toString('base64')}`;
            }
          }
        } catch (_) {}
      }
      return null;
    }

    // Universal extractor untuk mengekstrak foto/gambar produk dari payload GoWA / whatsmeow
    async function findImageMedia(obj, depth = 0) {
      if (!obj || depth > 10) return null;

      async function toBase64Jpeg(val) {
        if (!val) return null;
        if (typeof val === 'string') {
          const s = val.trim();
          if (s.startsWith('data:image/')) {
            return s;
          }

          // 1. Cek file lokal di disk VPS
          const fromDisk = resolveLocalMediaFile(s);
          if (fromDisk) return fromDisk;

          // 2. Cek jika URL http/https — fetch langsung jika bukan WhatsApp CDN
          if (s.startsWith('http://') || s.startsWith('https://')) {
            if (!s.includes('whatsapp.net') && !s.includes('mmg.whatsapp')) {
              try {
                const fetchRes = await safeFetch(s, { timeout: 5000 });
                if (fetchRes.ok) {
                  const cType = fetchRes.headers.get('content-type') || '';
                  if (cType.startsWith('image/') || cType.startsWith('application/octet')) {
                    const arrayBuf = await fetchRes.arrayBuffer();
                    const buf = Buffer.from(arrayBuf);
                    if (buf.length > 0) {
                      const mime = cType.startsWith('image/') ? cType : 'image/jpeg';
                      return `data:${mime};base64,${buf.toString('base64')}`;
                    }
                  }
                }
              } catch (e) {
                console.log(`⚠️ Gagal fetch media URL: ${s.substring(0, 80)} — ${e.message}`);
              }
              return s;
            }
          }

          // 3. Cek jika path lokal relatif GoWA (contoh: statics/media/xxx.jpg atau /statics/xxx)
          if (s.startsWith('/') || s.startsWith('statics') || s.includes('statics/')) {
            const fromHttp = await fetchGoWAMediaHttp(s);
            if (fromHttp) return fromHttp;
          }

          // 4. Cek string base64 murni
          const clean = s.replace(/\s+/g, '');
          if (clean.length > 50 && /^[A-Za-z0-9+/=]+$/.test(clean.substring(0, 100))) {
            return `data:image/jpeg;base64,${clean}`;
          }
          return null;
        }

        if (typeof Buffer !== 'undefined' && Buffer.isBuffer(val)) {
          return `data:image/jpeg;base64,${val.toString('base64')}`;
        }
        if (Array.isArray(val) && val.length > 30) {
          return `data:image/jpeg;base64,${Buffer.from(val).toString('base64')}`;
        }
        if (typeof val === 'object' && val !== null) {
          if (val.type === 'Buffer' && Array.isArray(val.data)) {
            return `data:image/jpeg;base64,${Buffer.from(val.data).toString('base64')}`;
          }
          // Objek { path: "statics/media/..." } dari GoWA buildAutoDownloadPayload
          if (val.path && typeof val.path === 'string') {
            const fromDisk = resolveLocalMediaFile(val.path);
            if (fromDisk) return fromDisk;
            const fromHttp = await fetchGoWAMediaHttp(val.path);
            if (fromHttp) return fromHttp;
          }
          if (val.url && typeof val.url === 'string' && !val.url.includes('whatsapp.net')) {
            const fromUrl = await toBase64Jpeg(val.url);
            if (fromUrl) return fromUrl;
          }
          if (val.jpegThumbnail) {
            const thumb = await toBase64Jpeg(val.jpegThumbnail);
            if (thumb) return thumb;
          }
        }
        return null;
      }

      // 1. WhatsApp media containers
      const mediaContainers = ['imageMessage', 'documentMessage', 'videoMessage', 'stickerMessage'];
      for (const mc of mediaContainers) {
        if (obj[mc] && typeof obj[mc] === 'object') {
          const m = obj[mc];
          if (m.jpegThumbnail) {
            const thumb = await toBase64Jpeg(m.jpegThumbnail);
            if (thumb) return thumb;
          }
          if (m.url && typeof m.url === 'string' && m.url.startsWith('http') && !m.url.includes('whatsapp.net')) {
            const resolved = await toBase64Jpeg(m.url.trim());
            if (resolved) return resolved;
          }
          if (m.mediaUrl || m.media_url || m.file || m.base64 || m.image || m.path) {
            const direct = await toBase64Jpeg(m.mediaUrl || m.media_url || m.file || m.base64 || m.image || m.path);
            if (direct) return direct;
          }
        }
      }

      // 2. Direct candidate keys (GoWA + whatsmeow + generic)
      const targetKeys = [
        'path', 'filepath', 'file_path', 'mediapath', 'media_path',
        'productimageurl', 'imageurl', 'image_url', 'photourl', 'photo_url',
        'image', 'photo', 'picture', 'media_url', 'mediaurl', 'file_url', 'fileurl',
        'url', 'uri', 'jpegthumbnail', 'thumbnail', 'base64', 'media', 'attachment',
        'media_data', 'file_data', 'file', 'sticker', 'document'
      ];

      for (const key of Object.keys(obj)) {
        const lowerKey = key.toLowerCase();
        if (targetKeys.includes(lowerKey)) {
          const val = obj[key];
          const parsed = await toBase64Jpeg(val);
          if (parsed) return parsed;
          if (typeof val === 'object' && val !== null) {
            const nested = await findImageMedia(val, depth + 1);
            if (nested) return nested;
          }
        }
      }

      // 3. Jelajahi nested data/message
      for (const key of ['data', 'message', 'payload', 'msg', 'body', 'ephemeralMessage', 'viewOnceMessage', 'quotedMessage', 'contextInfo']) {
        if (obj[key] && typeof obj[key] === 'object') {
          const nested = await findImageMedia(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      for (const key of Object.keys(obj)) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const nested = await findImageMedia(obj[key], depth + 1);
          if (nested) return nested;
        }
      }

      return null;
    }

    const rawMessage = findTextMessage(body).trim();
    let productImageUrl = await findImageMedia(body);
    const messageId = findField(body, ['id', 'message_id', 'msg_id', 'stanza_id']);

    // Deteksi Group JID vs Sender Phone secara presisi:
    // Pada webhook WhatsApp (GoWA / whatsmeow / Baileys):
    // - Jika pesan grup: 'from', 'chat_id', 'remote_jid', 'jid', atau 'chat' berakhiran '@g.us'.
    // - Nomor pengirim individu ada di 'participant', 'sender', atau 'sender_phone'.
    // - Jika pesan 1-on-1 (japri): 'from' berakhiran '@s.whatsapp.net'.
    let fromGroup = '';
    const rawFrom = findField(body, ['from', 'chat_id', 'chatid', 'remote_jid', 'remotejid', 'jid', 'chat', 'group_id']);
    if (rawFrom && rawFrom.endsWith('@g.us')) {
      fromGroup = rawFrom;
    } else {
      const groupCandidates = [
        findField(body, ['chat_id', 'chatid']),
        findField(body, ['remote_jid', 'remotejid']),
        findField(body, ['jid']),
        findField(body, ['group_id'])
      ];
      const foundG = groupCandidates.find(g => g && typeof g === 'string' && g.endsWith('@g.us'));
      if (foundG) fromGroup = foundG;
    }

    let senderPhone = '';
    const participant = findField(body, ['participant', 'sender', 'sender_phone', 'senderphone']);
    if (participant && !participant.endsWith('@g.us')) {
      senderPhone = participant;
    } else if (rawFrom && !rawFrom.endsWith('@g.us')) {
      senderPhone = rawFrom;
    }

    const senderName = findField(body, ['push_name', 'pushname', 'sender_name', 'name', 'notify']);
    const timestamp = Date.now();

    // ─── Proactive GoWA Media Download API Fallback ───
    // Jika belum dapat gambar tetapi terindikasi ada media gambar dengan messageId
    if (!productImageUrl && messageId) {
      const isMediaCandidate = Boolean(
        findField(body, ['media_type', 'mediatype', 'type']) === 'image' ||
        JSON.stringify(body).includes('imageMessage') ||
        JSON.stringify(body).includes('mmg.whatsapp.net') ||
        (body && body.payload && body.payload.image) ||
        (body && body.image)
      );

      if (isMediaCandidate) {
        console.log(`🔄 [GoWA Download API] Mencoba request unduh media untuk messageId ${messageId}...`);
        const candidateHosts = [
          process.env.GOWA_URL,
          'http://127.0.0.1:3000',
          'http://localhost:3000',
          'http://127.0.0.1:8080',
          'http://127.0.0.1:8000'
        ].filter(Boolean);

        const chatJid = fromGroup || senderPhone || '';
        const cleanPhone = chatJid.replace(/@.*$/, '');
        const phoneVariants = [chatJid, cleanPhone].filter(Boolean);

        for (const host of candidateHosts) {
          if (productImageUrl) break;
          for (const ph of phoneVariants) {
            try {
              const downloadUrl = `${host.replace(/\/+$/, '')}/message/${messageId}/download?phone=${encodeURIComponent(ph)}`;
              const headers = {};
              if (process.env.GOWA_BASIC_AUTH) {
                headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
              }
              const dlRes = await safeFetch(downloadUrl, { headers, timeout: 6000 });
              if (dlRes.ok) {
                const dlJson = await dlRes.json();
                const resObj = dlJson.results || dlJson.data || dlJson;
                const downloadedPath = resObj.file_path || resObj.filePath || resObj.path;
                const downloadedUrl = resObj.file_url || resObj.fileUrl || resObj.url;

                if (downloadedPath) {
                  const fromDisk = resolveLocalMediaFile(downloadedPath);
                  if (fromDisk) {
                    productImageUrl = fromDisk;
                    break;
                  }
                }
                if (downloadedUrl) {
                  const fromHttp = await fetchGoWAMediaHttp(downloadedUrl);
                  if (fromHttp) {
                    productImageUrl = fromHttp;
                    break;
                  }
                }
              }
            } catch (dlErr) {
              // Lanjut ke varian/host berikutnya
            }
          }
        }
      }
    }

    // ─── Instant Thumbnail Fallback ───
    // Jika belum dapat file penuh, cari jpegThumbnail bawaan WhatsApp protobuf di seluruh payload
    if (!productImageUrl) {
      function findAnyThumbnail(o, d = 0) {
        if (!o || d > 8 || typeof o !== 'object') return null;
        for (const k of Object.keys(o)) {
          const lk = k.toLowerCase();
          if (lk === 'jpegthumbnail' || lk === 'thumbnail') {
            const v = o[k];
            if (typeof v === 'string' && v.trim().length > 20) {
              const s = v.trim();
              return s.startsWith('data:image/') ? s : `data:image/jpeg;base64,${s.replace(/\s+/g, '')}`;
            }
            if (Buffer.isBuffer(v)) {
              return `data:image/jpeg;base64,${v.toString('base64')}`;
            }
            if (Array.isArray(v) && v.length > 20) {
              return `data:image/jpeg;base64,${Buffer.from(v).toString('base64')}`;
            }
            if (v && v.type === 'Buffer' && Array.isArray(v.data)) {
              return `data:image/jpeg;base64,${Buffer.from(v.data).toString('base64')}`;
            }
          }
        }
        for (const k of Object.keys(o)) {
          if (o[k] && typeof o[k] === 'object') {
            const found = findAnyThumbnail(o[k], d + 1);
            if (found) return found;
          }
        }
        return null;
      }
      const thumb = findAnyThumbnail(body);
      if (thumb) {
        console.log(`📸 [MEDIA] Berhasil mengekstrak thumbnail JPEG dari protobuf WhatsApp (${thumb.substring(0, 35)}...)`);
        productImageUrl = thumb;
      }
    }

    console.log(`🔍 [DEBUG] rawMessage: "${(rawMessage || '').substring(0, 60)}" | image: ${productImageUrl ? 'YES' : 'NO'} | from: ${senderPhone} | group: ${fromGroup} | name: ${senderName}`);

    const isGroupChat = Boolean(fromGroup && fromGroup.endsWith('@g.us'));

    // ─── 1. VALIDASI SUMBER PESAN (JAPRI VS GRUP CX) ───
    // Sesuai requirement: Foto via japri ke nomor bot TIDAK BOLEH otomatis jadi task complain!
    // Seluruh task complain dan cancel HANYA dipicu dari grup WhatsApp resmi: "CX <> QA Fresh Discussion".
    if (!isGroupChat) {
      console.log(`ℹ️ [JAPRI] Pesan/foto dari direct chat (${senderPhone || senderName || 'Japri'}) diabaikan. Task complain & cancel hanya dipicu dari grup WhatsApp CX <> QA Fresh Discussion.`);
      return res.status(200).json({
        status: 'ignored',
        reason: 'Pesan japri (direct chat) diabaikan. Task complain dan notifikasi cancel hanya dipicu dari grup CX <> QA Fresh Discussion.'
      });
    }

    // Resolusi nama grup dari payload / cache / GoWA API
    const groupName = await resolveGroupName(fromGroup, body, findField);
    const isCxQaGroup = matchesCxQaGroup(groupName) || matchesCxQaGroup(fromGroup);

    if (isCxQaGroup) {
      console.log(`💬 [GRUP CX <> QA] Pesan terdeteksi dari grup CX: "${groupName || fromGroup}"`);
    } else {
      console.log(`👥 [GRUP LAIN] Pesan dari grup WhatsApp: "${groupName || fromGroup}" (memerlukan trigger eksplisit Hub MTG Menteng)`);
    }

    let effectiveMessage = rawMessage;
    if (!effectiveMessage && productImageUrl) {
      if (isCxQaGroup) {
        // Jika ada foto produk di grup CX tanpa teks caption
        effectiveMessage = `Complain Hub MTG Menteng\nInv: INV-FOTO-${Date.now().toString().slice(-6)}\nDetail: Kendala foto produk dari grup CX <> QA Fresh Discussion\nPengirim: ${senderName || 'Tim CX'}`;
        console.log('📸 [Grup CX <> QA] Foto kendala produk tanpa caption di grup CX terdeteksi, membuat task complain.');
      } else {
        console.log('ℹ️ [Group Chat] Pesan foto tanpa caption di grup lain diabaikan (karena grup multi-hub wajib mencantumkan Hub MTG Menteng).');
      }
    }

    if (!effectiveMessage) {
      console.log(`ℹ️ [Event: ${body.event || 'update'}] Diabaikan (bukan pesan teks atau media kendala)`);
      return res.status(200).json({ status: 'ignored', reason: 'No message content or media' });
    }

    console.log(`📩 Pesan WA Diterima: "${effectiveMessage.substring(0, 70).replace(/\n/g, ' ')}..." [Dari: ${senderName || senderPhone || 'Unknown'}] [Grup: ${groupName || fromGroup}]`);
    if (productImageUrl) {
      console.log(`📸 Foto Produk Terlampir: Ya (${productImageUrl.substring(0, 30)}...)`);
    }

    // Parse pesan menggunakan parser
    const meta = {
      messageId,
      fromGroup,
      groupName,
      isCxQaGroup,
      senderPhone,
      senderName,
      timestamp,
      productImageUrl
    };

    const customTriggers = process.env.CUSTOM_TRIGGERS
      ? process.env.CUSTOM_TRIGGERS.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const complain = parseComplainMessage(effectiveMessage, meta, customTriggers);

    if (!complain) {
      console.log(`ℹ️ Diabaikan (bukan pesan complain/cancel/trigger): "${effectiveMessage.substring(0, 50).replace(/\n/g, ' ')}"`);
      return res.status(200).json({
        status: 'ignored',
        reason: 'Pesan tidak mengandung trigger complain atau pembatalan pesanan (cancel)'
      });
    }

    if (complain.type === 'cancel') {
      console.log(`🚫 CANCEL ORDER TERDETEKSI! Merekam pembatalan: [${complain.hub}] ${complain.invoice} - ${complain.description.substring(0, 50)}`);
    } else {
      console.log(`🎯 COMPLAIN TERDETEKSI! Merekam task: [${complain.hub}] ${complain.invoice} - ${complain.description.substring(0, 50)}`);
    }

    // Simpan ke Firestore / Local DB
    await saveComplain(complain);

    // Kirim Push Notification FCM ke seluruh user SuperApp MTG
    const notifResult = await sendPushNotification(complain);

    const typeTitle = complain.type === 'cancel' ? 'Cancel order' : 'Complain';
    return res.status(201).json({
      status: 'success',
      type: complain.type,
      message: `${typeTitle} berhasil diproses dan notifikasi telah dikirim`,
      complain,
      notification: notifResult
    });

  } catch (err) {
    console.error('❌ Error handling webhook:', err);
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
});

// ─── 2. REST API: Get All Complaints ───
app.get('/api/complaints', async (req, res) => {
  try {
    const status = req.query.status || 'semua';
    const list = await getAllComplaints(status);
    res.json({
      success: true,
      count: list.length,
      data: list
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 3. REST API: Claim Complain ───
app.post('/api/complaints/:id/claim', async (req, res) => {
  try {
    const { id } = req.params;
    const { userName = 'Tim Warehouse MTG' } = req.body;
    const updated = await claimComplain(id, userName);

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4. REST API: Resolve Complain (Upload Bukti Selesai) ───
app.post('/api/complaints/:id/resolve', async (req, res) => {
  try {
    const { id } = req.params;
    const { evidenceUrl } = req.body;

    if (!evidenceUrl) {
      return res.status(400).json({ success: false, error: 'Bukti screenshot (evidenceUrl) wajib disertakan' });
    }

    const updated = await resolveComplain(id, evidenceUrl);

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4b. REST API Admin: Delete Single Complain ───
app.delete('/api/complaints/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const success = await deleteComplain(id);
    if (!success) {
      return res.status(404).json({ success: false, error: 'Complain tidak ditemukan' });
    }
    res.json({ success: true, message: `Complain ${id} berhasil dihapus` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4c. REST API Admin: Clear Resolved Complaints ───
app.post('/api/complaints/clear-resolved', async (req, res) => {
  try {
    const result = await clearResolvedComplaints();
    res.json({
      success: true,
      message: `${result.clearedCount} complain berstatus selesai berhasil dibersihkan`,
      data: result
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4d. REST API Admin: Clear All Complaints (Reset) ───
app.post('/api/complaints/clear-all', async (req, res) => {
  try {
    const { pin = '' } = req.body;
    // Simple admin PIN verification
    const expectedPin = process.env.ADMIN_PIN || '1234';
    if (String(pin).trim() !== String(expectedPin).trim()) {
      return res.status(403).json({ success: false, error: 'PIN Admin tidak valid' });
    }

    const result = await clearAllComplaints();
    res.json({
      success: true,
      message: `Seluruh data complain (${result.clearedCount} item) berhasil di-reset`,
      data: result
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── 4e. REST API Admin: Inspect Latest Webhook Payload ───
app.get('/api/latest-webhook', (req, res) => {
  const payloadPath = path.join(__dirname, 'latest_webhook_payload.json');
  if (fs.existsSync(payloadPath)) {
    try {
      const data = JSON.parse(fs.readFileSync(payloadPath, 'utf8'));
      return res.json({ success: true, payload: data });
    } catch (e) {
      return res.status(500).json({ success: false, error: e.message });
    }
  }
// ─── 4f. REST API Admin: Cek Kesehatan & Autentikasi FCM Push Notification ───
app.get('/api/fcm-health', async (req, res) => {
  try {
    const result = await checkFcmHealth();
    res.json(result);
  } catch (err) {
    res.status(500).json({ status: 'error', error: err.message });
  }
});

app.post('/api/test-fcm', async (req, res) => {
  try {
    const testComplain = {
      id: 'test-' + Date.now(),
      type: 'complain',
      hub: 'Hub MTG Menteng',
      invoice: 'INV-TEST-FCM',
      sender: 'Test FCM API',
      description: 'Ini adalah tes live pengiriman push notification FCM ke topik mtg_complaints.',
      productImageUrl: null,
      status: 'baru',
      createdAt: new Date().toISOString()
    };
    const result = await sendPushNotification(testComplain);
    res.json({
      success: result.success,
      result,
      targetTopic: FCM_TOPIC
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Helper Auto-Discovery Grup GoWA pada Boot & Tiap 5 Menit ───
async function fetchAndCacheGoWAGroups() {
  const candidateHosts = [
    process.env.GOWA_URL,
    'http://127.0.0.1:3000',
    'http://localhost:3000',
    'http://127.0.0.1:8080',
    'http://127.0.0.1:8000'
  ].filter(Boolean);

  const headers = {};
  if (process.env.GOWA_BASIC_AUTH) {
    headers['Authorization'] = 'Basic ' + Buffer.from(process.env.GOWA_BASIC_AUTH).toString('base64');
  }

  for (const host of candidateHosts) {
    for (const ep of ['/user/my/groups', '/group/list', '/groups']) {
      try {
        const res = await safeFetch(`${host.replace(/\/+$/, '')}${ep}`, { headers, timeout: 2500 });
        if (res.ok) {
          const data = await res.json();
          const list = data.data || data.results || (Array.isArray(data) ? data : null);
          if (Array.isArray(list) && list.length > 0) {
            for (const g of list) {
              const jid = g.jid || g.id || g.JID;
              const name = g.name || g.subject || g.Name;
              if (jid && name) {
                groupNameCache.set(String(jid), String(name).trim());
                if (matchesCxQaGroup(String(name))) {
                  console.log(`🎯 [GRUP CX DITEMUKAN] "${name}" -> JID: ${jid}`);
                }
              }
            }
            return;
          }
        }
      } catch (_) {}
    }
  }
}

// Start Server
app.listen(PORT, async () => {
  console.log(`\n══════════════════════════════════════════════════════════`);
  console.log(`🚀 GoWA Complain Webhook Server running on port ${PORT}`);
  console.log(`📡 Webhook URL   : http://localhost:${PORT}/webhook`);
  console.log(`📋 API Endpoint  : http://localhost:${PORT}/api/complaints`);
  console.log(`🔍 FCM Health    : GET http://localhost:${PORT}/api/fcm-health`);
  console.log(`🧪 Test Simulate : POST http://localhost:${PORT}/api/simulate-complain`);
  console.log(`══════════════════════════════════════════════════════════\n`);

  // Cek kesehatan FCM saat booting
  const fcmStatus = await checkFcmHealth();
  if (fcmStatus.ready) {
    console.log(`✅ [FCM] Siap menyiarkan push notification ke topic "${FCM_TOPIC}".`);
  } else {
    console.warn(`⚠️ [FCM NOTICE] Push notification belum siap: ${fcmStatus.error || fcmStatus.reason}`);
    console.warn(`💡 Jalankan 'node test_fcm.js' untuk panduan generate private key baru.`);
  }

  // Pre-fetch cache grup WhatsApp dari GoWA
  fetchAndCacheGoWAGroups().catch(() => {});
  setInterval(() => fetchAndCacheGoWAGroups().catch(() => {}), 300000);
});
