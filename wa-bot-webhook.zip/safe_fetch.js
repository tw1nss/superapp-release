'use strict';

const http = require('http');
const https = require('https');
const urlModule = require('url');

/**
 * Universal safe HTTP/HTTPS fetch compatible with all Node.js versions (Node 10+ / 12+ / 14+ / 16+ / 18+ / 20+).
 * Eliminates dependencies on global fetch or AbortSignal.
 */
function safeFetch(urlStr, options) {
  options = options || {};
  return new Promise((resolve, reject) => {
    try {
      const parsed = urlModule.parse(urlStr);
      const isHttps = parsed.protocol === 'https:';
      const transport = isHttps ? https : http;

      const headers = Object.assign({}, options.headers || {});
      if (options.body && !headers['Content-Type'] && !headers['content-type']) {
        if (typeof options.body === 'object') {
          headers['Content-Type'] = 'application/json';
        }
      }

      const reqOptions = {
        protocol: parsed.protocol,
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: (parsed.pathname || '') + (parsed.search || ''),
        method: options.method || 'GET',
        headers: headers
      };

      const timeoutMs = options.timeout || 8000;
      let timedOut = false;

      const req = transport.request(reqOptions, (res) => {
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          if (timedOut) return;
          const buf = Buffer.concat(chunks);
          resolve({
            ok: res.statusCode >= 200 && res.statusCode < 300,
            status: res.statusCode,
            headers: {
              get: (headerName) => {
                const lower = (headerName || '').toLowerCase();
                return res.headers[lower] || '';
              }
            },
            json: async () => JSON.parse(buf.toString('utf8')),
            text: async () => buf.toString('utf8'),
            arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength),
            buffer: async () => buf
          });
        });
      });

      req.on('timeout', () => {
        timedOut = true;
        req.destroy();
        reject(new Error('Request timeout to ' + urlStr));
      });

      req.setTimeout(timeoutMs);

      req.on('error', (err) => {
        if (!timedOut) reject(err);
      });

      if (options.body) {
        const bodyData = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
        req.write(bodyData);
      }
      req.end();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { safeFetch };
